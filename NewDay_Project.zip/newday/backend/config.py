"""Central settings for NewDay. Change thresholds / currency here."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIR = BASE_DIR.parent / "frontend"
MODEL_DIR = BASE_DIR / "models"
LEVELS_FILE = BASE_DIR / "levels.json"

# Database location (override with NEWDAY_DB env var; tests do this)
DB_PATH = Path(os.environ.get("NEWDAY_DB", BASE_DIR / "data" / "newday.db"))

CURRENCY = "₹"

# ---- Money-health rule (from the project brief) --------------------------
# savings ratio = (deposited - expenses) / deposited
#   ratio >= 50%  -> "high"  (you can spend a little more)
#   ratio <= 40%  -> "low"   (stop spending)
#   in between    -> "balanced"
HIGH_THRESHOLD = 0.50
LOW_THRESHOLD = 0.40

# Expense categories the ML model predicts
CATEGORIES = [
    "Food & Dining", "Groceries", "Transport", "Shopping", "Bills & Recharge",
    "Entertainment", "Health", "Education", "Rent & Housing", "Other",
]

# If the classifier is less sure than this, the category falls back to "Other"
MIN_CONFIDENCE = 0.35

# Login throttling (failed attempts allowed per window)
MAX_LOGIN_FAILS = 8
LOGIN_WINDOW_SECONDS = 300
