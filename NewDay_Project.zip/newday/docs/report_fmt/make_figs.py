"""Builds the figures for the format-compliant report -> img/*.png"""
from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image
import json

OUT = Path(__file__).parent / "img"; OUT.mkdir(exist_ok=True)
FONT = "'Times New Roman','Liberation Serif',serif"
INK, LINE, SOFT = "#111", "#333", "#f2f2f2"

def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

class Svg:
    def __init__(s, w, h): s.w, s.h, s.p = w, h, []
    def text(s, x, y, lines, size=15, bold=False, anchor="middle", fill=INK):
        n = len(lines); y0 = y - (n - 1) * (size + 2) / 2
        t = "".join(f'<tspan x="{x}" dy="{0 if i==0 else size+2}">{esc(l)}</tspan>' for i, l in enumerate(lines))
        s.p.append(f'<text x="{x}" y="{y0+size*0.35:.1f}" font-size="{size}" text-anchor="{anchor}" font-weight="{700 if bold else 400}" fill="{fill}">{t}</text>')
    def rect(s, cx, y, w, h, lines, fill="#fff", bold=False, size=15):
        s.p.append(f'<rect x="{cx-w/2}" y="{y}" width="{w}" height="{h}" rx="4" fill="{fill}" stroke="{LINE}" stroke-width="1.4"/>')
        s.text(cx, y + h/2, lines, size, bold)
    def oval(s, cx, y, w, h, label):
        s.p.append(f'<rect x="{cx-w/2}" y="{y}" width="{w}" height="{h}" rx="{h/2}" fill="#dcdcdc" stroke="{LINE}" stroke-width="1.4"/>')
        s.text(cx, y + h/2, [label], 15, True)
    def diamond(s, cx, y, w, h, lines):
        pts = f"{cx},{y} {cx+w/2},{y+h/2} {cx},{y+h} {cx-w/2},{y+h/2}"
        s.p.append(f'<polygon points="{pts}" fill="#fff" stroke="{LINE}" stroke-width="1.4"/>')
        s.text(cx, y + h/2, lines, 14)
    def line(s, d, arrow=True):
        s.p.append(f'<path d="{d}" fill="none" stroke="{LINE}" stroke-width="1.4" {"marker-end=\"url(#a)\"" if arrow else ""}/>')
    def label(s, x, y, t, anchor="middle"): s.text(x, y, [t], 13, False, anchor, "#222")
    def render(s):
        return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {s.w} {s.h}" width="{s.w}" height="{s.h}" style="font-family:{FONT}">'
                '<defs><marker id="a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" fill="#333"/></marker></defs>'
                + "".join(s.p) + "</svg>")

# ---------------- Figure: main flowchart ----------------
def flowchart():
    W = 660; cx = 235; g = 22
    y = 10; Y = {}
    def place(k, h, gap=g):
        nonlocal y
        Y[k] = y; y += h + gap
    for k, h, gap in [("start",30,g),("p1",44,g),("d1",60,g),("d2",60,32),("save",32,g),("calc",44,g),("d3",64,g),("d4",64,g),("chk",44,g),("upd",32,g),("end",30,0)]:
        place(k, h, gap)
    s = Svg(W, y + 10)
    s.oval(cx, Y["start"], 110, 30, "Start")
    s.rect(cx, Y["p1"], 280, 44, ["User enters a deposit,", "expense or investment"])
    s.diamond(cx, Y["d1"], 190, 60, ["Input valid?"])
    s.rect(535, Y["d1"]+13, 170, 34, ["Show error message"])
    s.diamond(cx, Y["d2"], 170, 60, ["Expense?"])
    s.rect(535, Y["d2"]+8, 170, 44, ["ML model predicts", "the category"])
    s.rect(cx, Y["save"], 280, 32, ["Save transaction in SQLite"])
    s.rect(cx, Y["calc"], 300, 44, ["Recompute totals, savings ratio,", "monthly limit and points"])
    s.diamond(cx, Y["d3"], 230, 64, ["Savings ratio", "50% or more?"])
    s.rect(535, Y["d3"]+10, 170, 44, ["HIGH popup: can", "spend a little more"])
    s.diamond(cx, Y["d4"], 230, 64, ["Savings ratio", "40% or less?"])
    s.rect(535, Y["d4"]+10, 170, 44, ["LOW popup: stop", "spending"])
    s.rect(cx, Y["chk"], 310, 44, ["Check large expense and level", "change; queue the popups"])
    s.rect(cx, Y["upd"], 280, 32, ["Update the dashboard"])
    s.oval(cx, Y["end"], 110, 30, "End")
    mid = lambda k, h: Y[k] + h/2
    s.line(f"M{cx} {Y['start']+30} V{Y['p1']}")
    s.line(f"M{cx} {Y['p1']+44} V{Y['d1']}")
    s.line(f"M{cx+95} {mid('d1',60)} H{535-85}"); s.label(cx+130, mid('d1',60)-6, "No")
    s.line(f"M535 {Y['d1']+13} V{mid('p1',44)} H{cx+140}")
    s.line(f"M{cx} {Y['d1']+60} V{Y['d2']}"); s.label(cx+14, Y['d1']+60+14, "Yes", "start")
    s.line(f"M{cx+85} {mid('d2',60)} H{535-85}"); s.label(cx+110, mid('d2',60)-6, "Yes")
    s.line(f"M535 {Y['d2']+52} V{Y['d2']+60+11} H{cx}", arrow=False)
    s.line(f"M{cx} {Y['d2']+60} V{Y['save']}"); s.label(cx+14, Y['d2']+60+26, "No", "start")
    s.line(f"M{cx} {Y['save']+32} V{Y['calc']}")
    s.line(f"M{cx} {Y['calc']+44} V{Y['d3']}")
    s.line(f"M{cx+115} {mid('d3',64)} H{535-85}"); s.label(cx+135, mid('d3',64)-6, "Yes")
    s.line(f"M{cx} {Y['d3']+64} V{Y['d4']}"); s.label(cx+14, Y['d3']+64+14, "No", "start")
    s.line(f"M{cx+115} {mid('d4',64)} H{535-85}"); s.label(cx+135, mid('d4',64)-6, "Yes")
    s.line(f"M{cx} {Y['d4']+64} V{Y['chk']}"); s.label(cx+14, Y['d4']+64+14, "No (balanced)", "start")
    yj = Y['chk'] + 22
    s.line(f"M620 {mid('d3',64)} H640 V{yj} H{cx+155}")
    s.line(f"M535 {Y['d4']+54} V{yj}", arrow=False)
    s.line(f"M{cx} {Y['chk']+44} V{Y['upd']}")
    s.line(f"M{cx} {Y['upd']+32} V{Y['end']}")
    return s.render()

# ---------------- Figure: classifier pipeline ----------------
def pipeline():
    s = Svg(700, 275)
    s.rect(87, 20, 150, 56, ["Expense note", "e.g. zomato dinner"])
    s.rect(252, 20, 130, 56, ["Clean text", "lower-case, trim"])
    s.rect(427, 20, 170, 56, ["TF-IDF features", "character n-grams 2 to 4"])
    s.rect(612, 20, 150, 56, ["Calibrated", "linear SVM"])
    for a, b in [(162, 187), (317, 342), (512, 537)]: s.line(f"M{a} 48 H{b}")
    s.diamond(612, 112, 160, 76, ["Top probability", "0.35 or more?"])
    s.line("M612 76 V112")
    s.rect(370, 132, 190, 44, ["Show the predicted", "category in the form"])
    s.line("M532 150 H465"); s.label(498, 142, "Yes")
    s.rect(587, 215, 220, 44, ["Fall back to Other; user", "can pick the category"])
    s.line("M612 188 V215"); s.label(626, 205, "No", "start")
    return s.render()

# ---------------- Figure: architecture ----------------
def architecture():
    s = Svg(700, 300)
    s.rect(88, 25, 168, 66, ["Browser", "HTML, CSS, JavaScript"], bold=False)
    s.rect(350, 25, 170, 66, ["Flask API (app.py)", "login, entries, popups"], fill="#e6e6e6")
    s.rect(605, 25, 150, 66, ["SQLite (db.py)", "users, transactions"])
    s.line("M172 58 H265"); s.line("M265 58 H172"); s.line("M435 58 H530"); s.line("M530 58 H435")
    s.label(217, 48, "JSON / HTTP"); s.label(482, 48, "read / write")
    s.line("M350 91 V118", arrow=False); s.line("M130 118 H570", arrow=False)
    for cx in (130, 350, 570): s.line(f"M{cx} 118 V140")
    s.rect(130, 140, 190, 66, ["Finance rules", "finance.py"])
    s.rect(350, 140, 190, 66, ["ML models", "ml.py"])
    s.rect(570, 140, 190, 66, ["Hinglish messages", "messages.py"])
    s.line("M350 206 V232"); s.label(362, 222, "loads when needed", "start")
    s.rect(350, 232, 250, 52, ["Trained classifier", "category_model.joblib"])
    return s.render()

figs = {"fig_flowchart": flowchart(), "fig_pipeline": pipeline(), "fig_architecture": architecture()}
html = "<html><body style='margin:0;background:#fff'>" + "".join(f"<div id='{k}' style='display:inline-block;background:#fff'>{v}</div><br>" for k, v in figs.items()) + "</body></html>"
(OUT / "figs.html").write_text(html)
with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
    pg = b.new_page(device_scale_factor=3, viewport={"width": 900, "height": 1200})
    pg.goto((OUT / "figs.html").as_uri())
    for k in figs: pg.locator("#" + k).screenshot(path=str(OUT / f"{k}.png"))
    b.close()

# ---------------- Figure: model comparison chart (matplotlib) ----------------
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams["font.family"] = ["Liberation Serif", "DejaVu Serif"]
m = json.load(open(Path(__file__).parents[2] / "backend/models/metrics.json"))["models"]
names = ["Logistic\nRegression", "Multinomial\nNaive Bayes", "Linear SVM\n(calibrated)"]
keys = ["Logistic Regression", "Multinomial Naive Bayes", "Linear SVM (calibrated)"]
seen = [m[k]["seen_words_accuracy"]*100 for k in keys]; unseen = [m[k]["unseen_words_accuracy"]*100 for k in keys]
fig, ax = plt.subplots(figsize=(6.2, 3.1), dpi=300)
x = range(3); w = 0.36
b1 = ax.bar([i-w/2 for i in x], seen, w, color="#1f3a5f", label="Seen words")
b2 = ax.bar([i+w/2 for i in x], unseen, w, color="#e0a030", hatch="///", edgecolor="#6b4a00", linewidth=0.6, label="Unseen words")
for bars in (b1, b2):
    for r in bars: ax.text(r.get_x()+r.get_width()/2, r.get_height()+1.5, f"{r.get_height():.1f}", ha="center", fontsize=9)
ax.set_xticks(list(x)); ax.set_xticklabels(names, fontsize=9.5); ax.set_ylim(0, 112); ax.set_ylabel("Accuracy (%)", fontsize=10)
ax.legend(frameon=False, fontsize=9, loc="upper right", ncol=2); ax.spines[["top", "right"]].set_visible(False)
fig.tight_layout(); fig.savefig(OUT / "fig_models.png"); plt.close(fig)

# ---------------- Figure: screenshots composite ----------------
D = Path(__file__).parents[1] / "deck"
a = Image.open(D / "after.png").convert("RGB"); p_ = Image.open(D / "popup.png").convert("RGB")
H = 520; a = a.resize((int(a.width*H/a.height), H)); p_ = p_.resize((int(p_.width*H/p_.height), H))
comp = Image.new("RGB", (a.width + p_.width + 30, H), "white"); comp.paste(a, (0, 0)); comp.paste(p_, (a.width + 30, 0)); comp.save(OUT / "fig_low_popup.png")
Image.open(D / "before.png").convert("RGB").save(OUT / "fig_dashboard.png")
for f in sorted(OUT.glob("fig_*.png")): print(f.name, Image.open(f).size)
