"""Synthetic training data for the expense-category classifier.

No public dataset covers Indian Hinglish spending notes, so we generate labelled
descriptions from keyword lists (English + Hinglish), adding prefixes, suffixes
and typos to imitate how people actually type.
"""
import random

KEYWORDS = {
    "Food & Dining": [
        "pizza", "burger", "chai", "coffee", "samosa", "momos", "biryani", "thali", "canteen", "mess food",
        "zomato", "swiggy", "lunch", "dinner", "breakfast", "dosa", "maggi", "juice", "cafe", "restaurant",
        "ice cream", "chole bhature", "paratha", "snacks", "vada pav", "pani puri", "chaat", "sandwich",
        "cold drink", "lassi", "kathi roll", "dhaba", "pasta", "fries", "bhel", "tea", "idli", "noodles",
    ],
    "Groceries": [
        "sabzi", "vegetables", "milk", "doodh", "atta", "rice", "chawal", "dal", "kirana", "bigbasket",
        "blinkit", "zepto", "fruits", "eggs", "bread", "cooking oil", "masala", "grocery", "dmart", "ration",
        "paneer", "sugar", "curd", "dahi", "onions", "potatoes", "salt", "flour", "ghee", "instamart",
    ],
    "Transport": [
        "auto", "bus ticket", "metro", "uber", "ola", "rapido", "petrol", "diesel", "cab", "train ticket",
        "irctc", "fuel", "parking", "toll", "rickshaw", "flight ticket", "e-rickshaw", "fastag", "bike petrol",
        "metro card", "bus pass", "taxi", "shuttle", "local train", "cycle repair", "scooter service",
    ],
    "Shopping": [
        "shirt", "jeans", "shoes", "amazon", "flipkart", "myntra", "clothes", "kapde", "bag", "watch",
        "earphones", "headphones", "tshirt", "dress", "sneakers", "kurta", "accessories", "makeup",
        "perfume", "mobile cover", "gadget", "jacket", "sandals", "sunglasses", "meesho", "ajio", "charger",
    ],
    "Bills & Recharge": [
        "electricity bill", "bijli bill", "mobile recharge", "jio recharge", "airtel", "wifi bill",
        "broadband", "water bill", "gas cylinder", "dth recharge", "postpaid bill", "vi recharge",
        "insurance premium", "emi", "credit card bill", "phone bill", "internet bill", "tata sky",
        "loan emi", "lpg", "data pack", "sim recharge", "gas bill",
    ],
    "Entertainment": [
        "movie", "netflix", "spotify", "pvr", "game purchase", "bgmi uc", "steam", "concert", "hotstar",
        "prime video", "party", "bowling", "youtube premium", "show ticket", "outing", "club entry",
        "cinema", "inox", "arcade", "gaming", "stand up show", "amusement park", "ott subscription",
    ],
    "Health": [
        "medicine", "dawai", "doctor", "clinic", "pharmacy", "hospital", "gym", "checkup", "dentist",
        "tablets", "vitamins", "apollo", "medplus", "eye test", "physiotherapy", "blood test", "syrup",
        "gym membership", "yoga class", "health checkup", "ointment", "cough syrup", "x-ray",
    ],
    "Education": [
        "books", "college fees", "tuition", "online course", "udemy", "coursera", "exam fee", "notebook",
        "stationery", "pen", "printout", "xerox", "coaching", "library fee", "lab fee", "project print",
        "certificate", "textbook", "study material", "test series", "admission form", "pencil", "exam form",
    ],
    "Rent & Housing": [
        "rent", "kiraya", "hostel fee", "pg rent", "maintenance", "society charges", "furniture",
        "plumber", "repair", "electrician", "house rent", "broker fee", "room rent", "security deposit",
        "flat rent", "mattress", "water tank", "carpenter", "paint work", "hostel rent",
    ],
    "Other": [
        "gift", "donation", "misc", "charity", "birthday present", "tip", "fine", "friend loan", "temple",
        "wedding shagun", "laundry", "haircut", "salon", "pet food", "lost money", "others", "unknown",
        "dhobi", "courier", "flowers", "photo frame", "greeting card", "lent to friend",
    ],
}

PREFIXES = ["", "", "", "", "", "paid ", "bought ", "bill ", "aaj ka ", "monthly ", "my ", "for ", "kal ka ", "weekly "]
SUFFIXES = ["", "", "", "", "", " upi", " cash", " payment", " online", " ka", " today", " yesterday", " paid"]


def _typo(rng, word):
    if len(word) < 5 or rng.random() > 0.15:
        return word
    i = rng.randrange(1, len(word) - 1)
    if rng.random() < 0.5:  # drop a letter
        return word[:i] + word[i + 1:]
    return word[:i] + word[i + 1] + word[i] + word[i + 2:]  # swap two letters


def make_text(rng, keyword):
    text = rng.choice(PREFIXES) + _typo(rng, keyword) + rng.choice(SUFFIXES)
    if rng.random() < 0.3:
        text = text.upper() if rng.random() < 0.3 else text.capitalize()
    return text.strip()


def build_dataset(keywords_by_cat=None, per_class=300, seed=42):
    """Returns (texts, labels)."""
    keywords_by_cat = keywords_by_cat or KEYWORDS
    rng = random.Random(seed)
    texts, labels = [], []
    for cat, kws in keywords_by_cat.items():
        for _ in range(per_class):
            texts.append(make_text(rng, rng.choice(kws)))
            labels.append(cat)
    return texts, labels


def split_keywords(holdout=0.2, seed=7):
    """Split each category's keywords into seen / unseen, to test generalisation."""
    rng = random.Random(seed)
    train, test = {}, {}
    for cat, kws in KEYWORDS.items():
        kws = kws[:]
        rng.shuffle(kws)
        k = max(3, int(len(kws) * holdout))
        test[cat], train[cat] = kws[:k], kws[k:]
    return train, test
