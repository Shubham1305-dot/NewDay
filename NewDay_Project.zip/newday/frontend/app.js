/* NewDay frontend: plain JavaScript, no build step. */
(() => {
  "use strict";

  const $ = (sel, root = document) => root.querySelector(sel);
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const money = (n) => (Math.round(n) < 0 ? "−" : "") + "₹" + Math.abs(Math.round(n)).toLocaleString("en-IN");
  const num = (n) => Math.round(n).toLocaleString("en-IN");

  const state = { data: null, type: "expense", authMode: "login" };

  // ---------------------------------------------------------------- API
  async function api(path, opts = {}) {
    const res = await fetch(path, {
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      method: opts.method || "GET",
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    let data = {};
    try { data = await res.json(); } catch (_) { /* empty body */ }
    if (!res.ok) {
      const err = new Error(data.error || "Something went wrong. Please try again.");
      err.status = res.status;
      throw err;
    }
    return data;
  }

  // ---------------------------------------------------------------- popups (queued)
  const dialog = $("#popup");
  const queue = [];
  let showing = false;

  function pushPopups(list) {
    list.forEach((p) => queue.push(p));
    nextPopup();
  }
  function nextPopup() {
    if (showing || !queue.length) return;
    const p = queue.shift();
    showing = true;
    dialog.className = p.kind;
    $("#popup-icon").textContent = p.icon;
    $("#popup-title").textContent = p.title;
    $("#popup-msg").textContent = p.message;
    if (p.kind === "low" || p.kind === "high") sessionStorage.setItem("nd_status", p.kind);
    dialog.showModal();
    $("#popup-ok").focus();
  }
  dialog.addEventListener("close", () => { showing = false; nextPopup(); });
  $("#popup-ok").addEventListener("click", () => dialog.close());
  dialog.addEventListener("click", (e) => { if (e.target === dialog) dialog.close(); });

  let toastTimer;
  function toast(msg) {
    const t = $("#toast");
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 2200);
  }

  // ---------------------------------------------------------------- auth
  function showAuth() {
    $("#app-view").hidden = true;
    $("#auth-view").hidden = false;
  }
  function setAuthMode(mode) {
    state.authMode = mode;
    $("#tab-login").setAttribute("aria-selected", mode === "login");
    $("#tab-signup").setAttribute("aria-selected", mode === "signup");
    $("#name-field").hidden = mode !== "signup";
    $("#auth-submit").textContent = mode === "login" ? "Log in" : "Create account";
    $("#auth-form").password.autocomplete = mode === "login" ? "current-password" : "new-password";
    $("#auth-error").textContent = "";
  }
  document.querySelectorAll("#auth-view .seg button").forEach((b) =>
    b.addEventListener("click", () => setAuthMode(b.dataset.mode)));

  $("#auth-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = e.target;
    const btn = $("#auth-submit");
    $("#auth-error").textContent = "";
    if (f.username.value.trim().length < 3) { $("#auth-error").textContent = "Username needs at least 3 characters."; return; }
    if (f.password.value.length < 6) { $("#auth-error").textContent = "Password needs at least 6 characters."; return; }
    btn.disabled = true;
    try {
      await api(state.authMode === "login" ? "/api/login" : "/api/register", {
        method: "POST",
        body: { username: f.username.value.trim(), password: f.password.value, name: f.name.value.trim() },
      });
      f.reset();
      await loadApp(true);
    } catch (err) {
      $("#auth-error").textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  });

  $("#btn-logout").addEventListener("click", async () => {
    try { await api("/api/logout", { method: "POST" }); } catch (_) { /* ignore */ }
    sessionStorage.removeItem("nd_status");
    state.data = null;
    showAuth();
  });

  // ---------------------------------------------------------------- rendering
  const STATUS = {
    low:      { color: "#ff7a7a", text: (p, s) => `Low: only ${p}% kept ${s}. Below 40% means slow down.` },
    balanced: { color: "#ffc857", text: (p, s) => `Balanced: ${p}% kept ${s}. Reach 50% to get more room to spend.` },
    high:     { color: "#4fd6b8", text: (p, s) => `High: ${p}% kept ${s}. You have room for a little more spending.` },
    no_data:  { color: "#ffc857", text: () => "Add your first deposit to get started." },
  };
  const CAT_ICON = {
    "Food & Dining": "🍜", "Groceries": "🥬", "Transport": "🚌", "Shopping": "🛍️", "Bills & Recharge": "📱",
    "Entertainment": "🎬", "Health": "💊", "Education": "📚", "Rent & Housing": "🏠", "Other": "🧾",
  };
  const TYPE_ICON = { deposit: "💰", investment: "📈" };
  const PALETTE = ["#1f9d8a", "#f5a524", "#e5484d", "#4c6ef5", "#9b5de5", "#00a6d6", "#8d6e63", "#d6336c", "#6c757d", "#74b816"];

  function renderGauge(d) {
    const L = Math.PI * 100;
    const p = Math.max(0, Math.min(1, d.savings.ratio));
    const st = STATUS[d.savings.status] || STATUS.no_data;
    const pt = (f, r) => [120 - r * Math.cos(Math.PI * f), 125 - r * Math.sin(Math.PI * f)];
    const arc = "M 20 125 A 100 100 0 0 1 220 125";
    const seg = (a, b, color, op) =>
      `<path d="${arc}" fill="none" stroke="${color}" stroke-opacity="${op}" stroke-width="14" stroke-dasharray="${(b - a) * L} ${L}" stroke-dashoffset="${-a * L}"/>`;
    const lo = d.savings.low_threshold, hi = d.savings.high_threshold;
    const tick = (f, label) => {
      const [x1, y1] = pt(f, 86), [x2, y2] = pt(f, 112), [tx, ty] = pt(f, 126);
      return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#fff" stroke-opacity=".9" stroke-width="2"/>
              <text x="${tx}" y="${ty + 4}" text-anchor="middle" fill="#fff" font-size="12" font-weight="600">${label}</text>`;
    };
    const [sx, sy] = pt(p, 100);
    const has = d.savings.status !== "no_data";
    const sun = has ? `<circle cx="${sx}" cy="${sy}" r="15" fill="#ffd166" fill-opacity=".35"/><circle cx="${sx}" cy="${sy}" r="9" fill="#ffd166" stroke="#fff" stroke-width="2"/>` : "";
    const fill = has && p > 0 ? `<path d="${arc}" fill="none" stroke="${st.color}" stroke-width="14" stroke-linecap="round" stroke-dasharray="${p * L} ${L}"/>` : "";
    $("#gauge").setAttribute("viewBox", "-6 -22 252 176");
    $("#gauge").setAttribute("aria-label", has ? `Savings gauge: ${d.savings.percent} percent kept, status ${d.savings.status}` : "Savings gauge: no deposits yet");
    $("#gauge").innerHTML =
      seg(0, lo, "#ff7a7a", 0.35) + seg(lo, hi, "#ffc857", 0.35) + seg(hi, 1, "#4fd6b8", 0.35) +
      fill + tick(lo, `${Math.round(lo * 100)}%`) + tick(hi, `${Math.round(hi * 100)}%`) + sun +
      `<text x="120" y="108" text-anchor="middle" fill="#fff" font-family="Bricolage Grotesque, system-ui, sans-serif" font-size="40" font-weight="800">${has ? d.savings.percent + "%" : "–"}</text>
       <text x="120" y="128" text-anchor="middle" fill="#fff" fill-opacity=".85" font-size="13">saved</text>`;
  }

  function renderHero(d) {
    renderGauge(d);
    const m = d.month, s = d.savings;
    $("#hero-amount").textContent = money(m.remaining);
    let sub;
    if (s.status === "no_data") sub = "Your monthly budget appears after your first deposit.";
    else if (m.remaining > 0) sub = `About ${money(m.daily_limit)} a day for the next ${m.days_left} day${m.days_left === 1 ? "" : "s"}.`;
    else if (m.overspent) sub = "This month's budget is used up. Keep spending to the essentials.";
    else sub = "Nothing safe to spend right now.";
    $("#hero-sub").textContent = sub;
    const scope = d.scope === "month" ? "of this month's deposits" : "of all your deposits";
    const st = STATUS[s.status] || STATUS.no_data;
    $("#status-line").textContent = st.text(s.percent, scope);
  }

  function renderLevel(d) {
    const l = d.level;
    $("#chip-level").textContent = `Level ${l.level}: ${l.title}`;
    $("#lvl-count").textContent = `Level ${l.level} of ${l.total_levels}`;
    $("#lvl-num").textContent = l.level;
    $("#lvl-title").innerHTML = `${esc(l.title)}<small>${esc(l.name)}</small>`;
    const pct = Math.round(l.progress * 100);
    $("#lvl-fill").style.width = pct + "%";
    $("#lvl-bar").setAttribute("aria-valuenow", pct);
    $("#lvl-bar").setAttribute("aria-label", `Progress to next level: ${pct} percent`);
    $("#lvl-next").textContent = l.next
      ? `${num(l.points)} points. ${num(l.points_to_next)} more to reach Level ${l.next.level}: ${l.next.title}.`
      : `${num(l.points)} points. You are at the top level.`;
  }

  function renderTotals(d) {
    const t = d.totals;
    $("#t-dep").textContent = money(t.deposited);
    $("#t-exp").textContent = money(t.expenses);
    $("#t-avail").textContent = money(t.available);
    $("#t-avail-sub").textContent = `Cash ${money(t.cash)} and invested ${money(t.investments)}`;
    $("#t-inv").textContent = money(t.investments);
  }

  function renderList(d) {
    const ul = $("#tx-list");
    if (!d.recent.length) {
      ul.innerHTML = `<li class="empty" style="display:block">Nothing here yet. Add a deposit first, then log your spending.</li>`;
      return;
    }
    ul.innerHTML = d.recent.map((t) => {
      const icon = t.type === "expense" ? (CAT_ICON[t.category] || "🧾") : TYPE_ICON[t.type];
      const sign = t.type === "deposit" ? "+" : t.type === "expense" ? "−" : "→";
      const meta = t.type === "expense" ? `${esc(t.category)}, ${esc(t.date)}` : `${esc(t.date)}`;
      return `<li>
        <span class="ico ${t.type}" aria-hidden="true">${icon}</span>
        <span class="tx-main"><span class="tx-desc">${esc(t.description)}</span><span class="tx-meta">${meta}</span></span>
        <span class="amt ${t.type}">${sign}${money(t.amount)}</span>
        <button class="del" data-id="${t.id}" aria-label="Delete ${esc(t.description)}">✕</button>
      </li>`;
    }).join("");
  }

  function renderCategories(d) {
    const month = d.categories.month, rows = month.length ? month : d.categories.all;
    $("#cat-scope").textContent = !rows.length ? "" : month.length ? "This month" : "All time (nothing spent this month yet)";
    const donut = $("#donut"), legend = $("#legend");
    if (!rows.length) {
      donut.style.background = "#e4e9f1";
      legend.innerHTML = `<li class="empty">No spending recorded yet. Add an expense to see the split.</li>`;
      return;
    }
    let acc = 0;
    const stops = rows.map((r) => {
      const c = PALETTE[Math.max(0, d.category_list.indexOf(r.category)) % PALETTE.length];
      const from = acc; acc += r.percent;
      return `${c} ${from}% ${Math.min(100, acc)}%`;
    });
    donut.style.background = `conic-gradient(${stops.join(", ")})`;
    donut.setAttribute("aria-label", "Spending by category: " + rows.map((r) => `${r.category} ${r.percent}%`).join(", "));
    legend.innerHTML = rows.map((r) => {
      const c = PALETTE[Math.max(0, d.category_list.indexOf(r.category)) % PALETTE.length];
      return `<li><span class="dot" style="background:${c}"></span><span class="nm">${esc(r.category)}</span><span class="pc">${money(r.amount)} (${r.percent}%)</span></li>`;
    }).join("");
  }

  function renderMonthly(d) {
    const W = 420, H = 210, top = 14, bottom = 28, left = 8;
    const series = d.monthly;
    const max = Math.max(1, ...series.map((m) => Math.max(m.deposits, m.expenses)));
    const plotH = H - top - bottom, slot = (W - left * 2) / series.length, bw = 22;
    let out = `<line x1="${left}" y1="${H - bottom}" x2="${W - left}" y2="${H - bottom}" stroke="#c9d2e0"/>`;
    series.forEach((m, i) => {
      const cx = left + slot * i + slot / 2;
      const hDep = (m.deposits / max) * plotH, hExp = (m.expenses / max) * plotH;
      out += `<g><title>${esc(m.label)}: deposited ${money(m.deposits)}, spent ${money(m.expenses)}</title>
        <rect x="${cx - bw - 2}" y="${H - bottom - hDep}" width="${bw}" height="${hDep}" rx="4" fill="#1f9d8a"/>
        <rect x="${cx + 2}" y="${H - bottom - hExp}" width="${bw}" height="${hExp}" rx="4" fill="#e5484d"/>
        <text x="${cx}" y="${H - 8}" text-anchor="middle">${esc(m.label)}</text></g>`;
    });
    $("#monthly-chart").innerHTML = out;
  }

  function renderInsights(d) {
    const f = d.forecast;
    if (f) {
      $("#fc-value").textContent = money(f.value);
      $("#fc-note").textContent = f.method === "ridge_trend"
        ? `Trend from your last ${f.months_used} months.`
        : `Average of your last ${f.months_used} finished month${f.months_used === 1 ? "" : "s"}.`;
    } else {
      $("#fc-value").textContent = "Not enough history yet";
      $("#fc-note").textContent = "Needs at least one finished month of data.";
    }
    const m = d.month;
    if (m.projected_spend != null) {
      $("#pace-value").textContent = money(m.projected_spend);
      $("#pace-note").textContent = m.projected_spend > m.allowance
        ? `Above this month's ${money(m.allowance)} allowance. Ease off a little.`
        : `Within this month's ${money(m.allowance)} allowance.`;
    } else {
      $("#pace-value").textContent = "Not enough data yet";
      $("#pace-note").textContent = "Needs at least 3 days of spending this month.";
    }
    $("#badges").innerHTML = d.badges.length
      ? d.badges.map((b) => `<li><span aria-hidden="true">${b.icon}</span> ${esc(b.label)}</li>`).join("")
      : `<li>None yet. Add your first deposit.</li>`;
  }

  function renderAll(d) {
    state.data = d;
    $("#hello").textContent = `Hi, ${d.user.name}`;
    renderHero(d); renderLevel(d); renderTotals(d); renderList(d);
    renderCategories(d); renderMonthly(d); renderInsights(d);
    const sel = $("#tx-form").category;
    if (sel.options.length <= 1) {
      sel.innerHTML = `<option value="">Auto-detect from description</option>` +
        d.category_list.map((c) => `<option>${esc(c)}</option>`).join("");
    }
  }

  // ---------------------------------------------------------------- entry form
  const form = $("#tx-form");
  const LABELS = {
    deposit: ["Add deposit", "pocket money, salary, scholarship…"],
    expense: ["Add expense", "chai, auto, recharge…"],
    investment: ["Add investment", "SIP, FD, stocks…"],
  };
  function setType(type) {
    state.type = type;
    document.querySelectorAll("#tx-form .seg button").forEach((b) => b.setAttribute("aria-selected", b.dataset.type === type));
    $("#cat-field").hidden = type !== "expense";
    $("#tx-submit").textContent = LABELS[type][0];
    form.description.placeholder = LABELS[type][1];
    $("#tx-error").textContent = "";
  }
  document.querySelectorAll("#tx-form .seg button").forEach((b) => b.addEventListener("click", () => setType(b.dataset.type)));

  let catTimer;
  form.description.addEventListener("input", () => {
    clearTimeout(catTimer);
    const text = form.description.value.trim();
    const hint = $("#cat-hint");
    if (state.type !== "expense" || !text) { hint.textContent = ""; return; }
    catTimer = setTimeout(async () => {
      try {
        const r = await api("/api/categorize", { method: "POST", body: { description: text } });
        hint.textContent = r.low_confidence
          ? "Not sure about this one. Pick a category below."
          : `Looks like ${r.category} (${Math.round(r.confidence * 100)}% sure).`;
      } catch (_) { hint.textContent = ""; }
    }, 350);
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const err = $("#tx-error"), btn = $("#tx-submit");
    err.textContent = "";
    const amount = parseFloat(form.amount.value);
    if (!(amount > 0)) { err.textContent = "Enter an amount greater than 0."; form.amount.focus(); return; }
    if (state.type === "expense" && !form.description.value.trim() && !form.category.value) {
      err.textContent = "Add a short description or pick a category."; form.description.focus(); return;
    }
    const body = { type: state.type, amount, description: form.description.value.trim(), date: form.date.value };
    if (state.type === "expense" && form.category.value) body.category = form.category.value;
    btn.disabled = true;
    try {
      const res = await api("/api/transactions", { method: "POST", body });
      renderAll(res.dashboard);
      toast(`${LABELS[state.type][0].replace("Add ", "")[0].toUpperCase()}${LABELS[state.type][0].replace("Add ", "").slice(1)} saved`);
      form.amount.value = ""; form.description.value = ""; form.category.value = ""; $("#cat-hint").textContent = "";
      pushPopups(res.popups);
    } catch (ex) {
      if (ex.status === 401) return showAuth();
      err.textContent = ex.message;
    } finally {
      btn.disabled = false;
    }
  });

  $("#tx-list").addEventListener("click", async (e) => {
    const btn = e.target.closest(".del");
    if (!btn || !confirm("Delete this entry?")) return;
    try {
      const res = await api(`/api/transactions/${btn.dataset.id}`, { method: "DELETE" });
      renderAll(res.dashboard);
      toast("Entry deleted");
    } catch (ex) {
      if (ex.status === 401) return showAuth();
      toast(ex.message);
    }
  });

  $("#btn-surprise").addEventListener("click", async () => {
    try {
      const r = await api("/api/surprise");
      pushPopups([{ kind: "surprise", icon: "🎁", title: "Surprise!", message: r.message.replace(/^🎁\s*/, "") }]);
    } catch (ex) { if (ex.status === 401) showAuth(); }
  });

  // ---------------------------------------------------------------- boot
  async function loadApp(freshLogin) {
    try {
      const me = await api("/api/me");
      if (!me.user) return showAuth();
      const d = await api("/api/dashboard");
      $("#auth-view").hidden = true;
      $("#app-view").hidden = false;
      renderAll(d);
      if (freshLogin) sessionStorage.removeItem("nd_status");
      // Show the low/high reminder once per session (not on every refresh).
      if (d.popup && (d.popup.kind === "low" || d.popup.kind === "high") && sessionStorage.getItem("nd_status") !== d.popup.kind) {
        pushPopups([d.popup]);
      }
    } catch (ex) {
      showAuth();
    }
  }

  const today = new Date().toLocaleDateString("en-CA");
  form.date.value = today;
  form.date.max = today;
  setType("expense");
  setAuthMode("login");
  loadApp(false);
})();
