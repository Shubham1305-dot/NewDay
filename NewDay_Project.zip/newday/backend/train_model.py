"""Train + evaluate the expense-category classifier.

    python train_model.py

Compares three models and picks the best. Two test sets are used:
  * "seen words"   - random split of the same keyword lists (easy, optimistic)
  * "unseen words" - keywords held out of training entirely (harder, more honest)
Model choice uses the unseen-words macro-F1. Results go to models/metrics.json.
"""
import json
import sys

import joblib
from sklearn.calibration import CalibratedClassifierCV
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, f1_score
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

import config
import training_data


def _pipeline(clf):
    tfidf = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4), lowercase=True, sublinear_tf=True)
    return Pipeline([("tfidf", tfidf), ("clf", clf)])


def candidates():
    return {
        "Logistic Regression": lambda: _pipeline(LogisticRegression(max_iter=2000, C=10)),
        "Multinomial Naive Bayes": lambda: _pipeline(MultinomialNB(alpha=0.1)),
        "Linear SVM (calibrated)": lambda: _pipeline(CalibratedClassifierCV(LinearSVC(), cv=3)),
    }


def evaluate():
    # Seen-words test
    texts, labels = training_data.build_dataset(per_class=300, seed=42)
    xtr, xte, ytr, yte = train_test_split(texts, labels, test_size=0.2, stratify=labels, random_state=1)

    # Unseen-words test
    kw_train, kw_test = training_data.split_keywords()
    ttr, ltr = training_data.build_dataset(kw_train, per_class=300, seed=11)
    tte, lte = training_data.build_dataset(kw_test, per_class=80, seed=12)

    results, reports = {}, {}
    for name, make in candidates().items():
        easy = make().fit(xtr, ytr)
        hard = make().fit(ttr, ltr)
        pred_hard = hard.predict(tte)
        results[name] = {
            "seen_words_accuracy": round(accuracy_score(yte, easy.predict(xte)), 4),
            "unseen_words_accuracy": round(accuracy_score(lte, pred_hard), 4),
            "unseen_words_macro_f1": round(f1_score(lte, pred_hard, average="macro"), 4),
        }
        reports[name] = classification_report(lte, pred_hard, output_dict=True, zero_division=0)

    best = max(results, key=lambda n: results[n]["unseen_words_macro_f1"])
    per_class = {c: round(reports[best][c]["f1-score"], 3) for c in config.CATEGORIES}
    return {
        "samples_total": len(texts),
        "classes": config.CATEGORIES,
        "models": results,
        "chosen_model": best,
        "chosen_per_class_f1_unseen_words": per_class,
        "note": "Data is synthetic (keyword templates + typos). Real-world accuracy will be lower; "
                "the unseen-words score is the more realistic estimate.",
    }


def train_and_save():
    metrics = evaluate()
    texts, labels = training_data.build_dataset(per_class=400, seed=99)
    model = candidates()[metrics["chosen_model"]]().fit(texts, labels)
    config.MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, config.MODEL_DIR / "category_model.joblib")
    (config.MODEL_DIR / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return metrics


if __name__ == "__main__":
    m = train_and_save()
    json.dump(m, sys.stdout, indent=2)
    print()
