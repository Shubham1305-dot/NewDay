"""SQLite storage. All queries are parameterised (no string-built SQL)."""
import sqlite3
from contextlib import contextmanager
from datetime import datetime

import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    name          TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    max_level     INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS transactions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type        TEXT NOT NULL CHECK (type IN ('deposit','expense','investment')),
    amount      REAL NOT NULL CHECK (amount > 0),
    category    TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    date        TEXT NOT NULL,
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tx_user_date ON transactions(user_id, date);
"""


@contextmanager
def connect():
    config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with connect() as c:
        c.executescript(SCHEMA)


def _now():
    return datetime.now().isoformat(timespec="seconds")


def create_user(username, name, password_hash):
    """Returns the new user id, or None if the username is taken."""
    try:
        with connect() as c:
            cur = c.execute(
                "INSERT INTO users (username, name, password_hash, created_at) VALUES (?,?,?,?)",
                (username.lower(), name, password_hash, _now()),
            )
            return cur.lastrowid
    except sqlite3.IntegrityError:
        return None


def get_user_by_username(username):
    with connect() as c:
        row = c.execute("SELECT * FROM users WHERE username = ?", (username.lower(),)).fetchone()
        return dict(row) if row else None


def get_user(user_id):
    with connect() as c:
        row = c.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        return dict(row) if row else None


def set_max_level(user_id, level):
    with connect() as c:
        c.execute("UPDATE users SET max_level = ? WHERE id = ?", (level, user_id))


def add_transaction(user_id, type_, amount, category, description, date_str):
    with connect() as c:
        cur = c.execute(
            "INSERT INTO transactions (user_id, type, amount, category, description, date, created_at) "
            "VALUES (?,?,?,?,?,?,?)",
            (user_id, type_, amount, category, description, date_str, _now()),
        )
        row = c.execute("SELECT * FROM transactions WHERE id = ?", (cur.lastrowid,)).fetchone()
        return dict(row)


def list_transactions(user_id):
    """All transactions, oldest first (what the finance engine wants)."""
    with connect() as c:
        rows = c.execute(
            "SELECT * FROM transactions WHERE user_id = ? ORDER BY date, id", (user_id,)
        ).fetchall()
        return [dict(r) for r in rows]


def delete_transaction(user_id, tx_id):
    with connect() as c:
        cur = c.execute("DELETE FROM transactions WHERE id = ? AND user_id = ?", (tx_id, user_id))
        return cur.rowcount > 0
