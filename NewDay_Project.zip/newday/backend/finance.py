"""Core finance engine. Pure functions: transactions in, dashboard numbers out.

Definitions (also in the README / report):
  deposited  D = all deposits
  expenses   E = all expenses
  invested   I = money moved into investments (not an expense)
  available    = D - E            (cash savings + invested money)
  cash         = D - E - I
  savings ratio = (D - E) / D     -> decides low / balanced / high
  points       = (D - E) - E      -> "savings - expenses"; drives levels
"""
import calendar
import json
from collections import defaultdict
from datetime import date, datetime

import config
import messages
import ml


# ---- levels -------------------------------------------------------------
def load_levels():
    data = json.loads(config.LEVELS_FILE.read_text(encoding="utf-8"))
    return sorted(data["levels"], key=lambda lv: lv["min_points"])


def level_info(points, levels=None):
    levels = levels or load_levels()
    current = levels[0]
    for lv in levels:
        if points >= lv["min_points"]:
            current = lv
    idx = levels.index(current)
    nxt = levels[idx + 1] if idx + 1 < len(levels) else None
    if nxt:
        span = nxt["min_points"] - current["min_points"]
        progress = (points - current["min_points"]) / span
        to_next = nxt["min_points"] - points
    else:
        progress, to_next = 1.0, 0
    return {
        "level": current["level"], "name": current["name"], "title": current["title"],
        "reward": current.get("reward", ""),
        "points": round(points, 2), "level_start": current["min_points"],
        "next": {"level": nxt["level"], "name": nxt["name"], "title": nxt["title"], "at": nxt["min_points"]} if nxt else None,
        "progress": round(max(0.0, min(1.0, progress)), 4),
        "points_to_next": round(max(0, to_next), 2),
        "total_levels": len(levels),
    }


# ---- status rule --------------------------------------------------------
def status_from_ratio(ratio, has_deposits=True):
    if not has_deposits:
        return "no_data"
    ratio = round(ratio, 6)  # avoid float noise at exactly 40% / 50%
    if ratio >= config.HIGH_THRESHOLD:
        return "high"
    if ratio <= config.LOW_THRESHOLD:
        return "low"
    return "balanced"


# ---- helpers ------------------------------------------------------------
def _parse(d):
    return datetime.strptime(d, "%Y-%m-%d").date()


def _month_back(year, month, k):
    idx = year * 12 + (month - 1) - k
    return idx // 12, idx % 12 + 1


def _breakdown(cat_totals):
    total = sum(cat_totals.values())
    rows = [{"category": c, "amount": round(a, 2), "percent": round(100 * a / total, 1) if total else 0}
            for c, a in sorted(cat_totals.items(), key=lambda kv: -kv[1])]
    return rows


def _badges(totals, status, streak, n_tx, has_invest):
    out = []
    if totals["deposited"] > 0:
        out.append({"id": "first_deposit", "label": "First deposit", "icon": "🌱"})
    if n_tx >= 10:
        out.append({"id": "tracker", "label": "10 entries tracked", "icon": "📒"})
    if has_invest:
        out.append({"id": "investor", "label": "First investment", "icon": "📈"})
    if status == "high":
        out.append({"id": "fifty_club", "label": "50% savings club", "icon": "💎"})
    if streak >= 3:
        out.append({"id": "streak", "label": f"{streak}-day no-spend streak", "icon": "🔥"})
    return out


# ---- main entry point ---------------------------------------------------
def compute_summary(txs, today=None, levels=None):
    today = today or date.today()
    levels = levels or load_levels()
    cur_month = today.strftime("%Y-%m")
    days_in_month = calendar.monthrange(today.year, today.month)[1]

    dep = exp = inv = 0.0
    m_dep = m_exp = m_inv = 0.0
    monthly = defaultdict(lambda: {"deposits": 0.0, "expenses": 0.0, "investments": 0.0})
    cat_all, cat_month = defaultdict(float), defaultdict(float)
    last_expense = None
    first_date = None

    for t in txs:
        a, ty, d = float(t["amount"]), t["type"], t["date"]
        mk = d[:7]
        first_date = min(first_date, d) if first_date else d
        if ty == "deposit":
            dep += a
            monthly[mk]["deposits"] += a
            m_dep += a if mk == cur_month else 0
        elif ty == "expense":
            exp += a
            monthly[mk]["expenses"] += a
            cat_all[t["category"]] += a
            if mk == cur_month:
                m_exp += a
                cat_month[t["category"]] += a
            last_expense = max(last_expense, d) if last_expense else d
        elif ty == "investment":
            inv += a
            monthly[mk]["investments"] += a
            m_inv += a if mk == cur_month else 0

    # Which period decides low / high? This month if money came in this month, else all time.
    if m_dep > 0:
        scope, base_dep, base_exp = "month", m_dep, m_exp
    else:
        scope, base_dep, base_exp = "lifetime", dep, exp
    ratio = (base_dep - base_exp) / base_dep if base_dep > 0 else 0.0
    status = status_from_ratio(ratio, has_deposits=base_dep > 0)

    available = dep - exp
    cash = dep - exp - inv

    # Monthly allowance: spend at most (1 - 50%) of the month's income and still stay in the "high" zone.
    month_deps = [v["deposits"] for v in monthly.values() if v["deposits"] > 0]
    base_income = m_dep if m_dep > 0 else (sum(month_deps) / len(month_deps) if month_deps else 0.0)
    allowance = base_income * (1 - config.HIGH_THRESHOLD)
    remaining = max(0.0, min(max(cash, 0.0), allowance - m_exp))
    days_left = days_in_month - today.day + 1
    daily = remaining / days_left if days_left else 0.0
    projected = (m_exp / today.day * days_in_month) if (today.day >= 3 and m_exp > 0) else None

    # Points and level (lifetime): (D - E) - E
    points = max(0.0, (dep - exp) - exp)
    lvl = level_info(points, levels)

    # Last 6 calendar months for the chart
    series = []
    for k in range(5, -1, -1):
        y, m = _month_back(today.year, today.month, k)
        key = f"{y}-{m:02d}"
        v = monthly.get(key, {"deposits": 0.0, "expenses": 0.0, "investments": 0.0})
        series.append({"month": key, "label": calendar.month_abbr[m],
                       "deposits": round(v["deposits"], 2), "expenses": round(v["expenses"], 2),
                       "investments": round(v["investments"], 2)})

    # ML forecast from completed months only
    past = sorted(k for k in monthly if k < cur_month)
    forecast = ml.forecast_next_month([monthly[k]["expenses"] for k in past])

    # No-spend streak
    if txs:
        ref = _parse(last_expense or first_date)
        streak = max(0, (today - ref).days) if last_expense else 0
    else:
        streak = 0

    totals = {"deposited": round(dep, 2), "expenses": round(exp, 2), "investments": round(inv, 2),
              "available": round(available, 2), "cash": round(cash, 2)}
    pct = int(round(max(0.0, min(1.0, ratio)) * 100))

    return {
        "currency": config.CURRENCY,
        "totals": totals,
        "scope": scope,
        "savings": {
            "ratio": round(ratio, 4), "percent": pct, "status": status,
            "low_threshold": config.LOW_THRESHOLD, "high_threshold": config.HIGH_THRESHOLD,
            "base_deposited": round(base_dep, 2), "base_expenses": round(base_exp, 2),
        },
        "month": {
            "key": cur_month, "deposited": round(m_dep, 2), "expenses": round(m_exp, 2),
            "investments": round(m_inv, 2), "allowance": round(allowance, 2),
            "remaining": round(remaining, 2), "daily_limit": round(daily, 2),
            "days_left": days_left, "overspent": base_income > 0 and m_exp > allowance,
            "projected_spend": round(projected, 2) if projected is not None else None,
        },
        "level": lvl,
        "categories": {"month": _breakdown(cat_month), "all": _breakdown(cat_all)},
        "monthly": series,
        "forecast": forecast,
        "streak_days": streak,
        "badges": _badges(totals, status, streak, len(txs), inv > 0),
        "popup": messages.status_popup(status, pct, remaining, daily),
    }
