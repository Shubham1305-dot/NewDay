# NewDay: money tracker with ML, levels and Hinglish nudges

Project for **Statistical Machine Learning**, School of Computer Science Engineering & Technology, Bennett University, July-Dec 2026.
Author: Subham (S25CSEU1605). Faculty: Sunakshi Singh.

NewDay tracks deposits, expenses and investments, tells you how much you can spend
this month, warns you in Hinglish when you are running low, and turns saving into a
game with levels.

## Run it

```bash
pip install -r requirements.txt
cd backend
python train_model.py      # optional: trains the category model (also runs automatically on first use)
python seed_demo.py        # optional: demo account  ->  demo / demo123
python app.py              # open http://127.0.0.1:5000
```

Run the tests from the project folder: `python -m unittest discover -s tests -v`

## How the numbers work

| Name | Meaning |
|---|---|
| Deposited (D) | all deposits |
| Expenses (E) | all expenses |
| Invested (I) | money moved into investments (not counted as an expense) |
| Total available | D − E (cash savings plus invested money) |
| Savings ratio | (D − E) ÷ D |
| Points | (D − E) − E, i.e. savings − expenses, never below 0 |

**Low / high rule**

- ratio **50% or more** → **high**: popup says you can spend a little more
- ratio **40% or less** → **low**: popup says stop spending
- between 40% and 50% → **balanced** (your brief did not cover this range, so it gets a neutral message)

The ratio uses this month's deposits if you deposited this month, otherwise all-time deposits.

**"You can spend this month"** = 50% of the month's income, minus what you already spent this month,
capped by the cash you actually have. Spending up to that limit keeps you in the "high" zone.
The daily figure is that amount divided by the days left in the month.

**Levels.** Points decide your level. The first level needs 5,000 points to cross.
Level names, titles, point thresholds and level-up surprises are all in
`backend/levels.json`. **The names there are placeholders. Replace them with yours.**
Points are live, so a big expense can drop you a level. The level-up popup only appears
the first time you reach a new highest level.

## The ML parts

1. **Expense category classifier** (`ml.py`, `train_model.py`): TF-IDF character n-grams plus a linear
   model. Three models are compared and the best is kept (see `backend/models/metrics.json`).
2. **Next-month spending forecast**: Ridge regression on monthly totals (a plain average when there are
   fewer than 3 finished months).
3. **Unusually large expense detection**: IsolationForest on log-amounts once you have 30+ expenses;
   a robust median/MAD rule before that.

### Honest limits

- The classifier is trained on **synthetic** data (keyword templates in English and Hinglish with typos),
  because no public Hinglish spending dataset exists. On words it has seen it scores about 99%.
  On words it has **never** seen it scores only about 30%. When it is unsure it falls back to "Other" and
  the form lets the user pick a category. The next improvement is learning from user corrections.
- Forecasts need at least one finished month of data.
- This is a learning project: there is no CSRF token, email verification or password reset.

## Dataset

The `dataset/` folder holds the synthetic training data, the keyword lists, the demo transactions and the experiment results. See `dataset/README.md`. Regenerate with `python backend/export_dataset.py`.

## Project layout

```
backend/   app.py (API)  finance.py (rules, levels)  ml.py  train_model.py  training_data.py
           messages.py (Hinglish popups)  db.py  config.py  levels.json  seed_demo.py
frontend/  index.html  style.css  app.js          (no build step, no frameworks)
tests/     test_newday.py                          (24 tests)
dataset/   synthetic training data, keywords, demo data, experiment results
docs/      screenshots, project report, presentation
```

## API summary

`POST /api/register` · `POST /api/login` · `POST /api/logout` · `GET /api/me` · `GET /api/dashboard` ·
`POST /api/transactions` · `DELETE /api/transactions/<id>` · `POST /api/categorize` · `GET /api/levels` · `GET /api/surprise`

Everything except register, login and `/api/me` needs a logged-in session.
