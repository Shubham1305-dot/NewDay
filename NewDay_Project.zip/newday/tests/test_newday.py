"""Run:  python -m unittest discover -s tests -v   (from the newday folder)"""
import os
import sys
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

import config  # noqa: E402

config.DB_PATH = Path(tempfile.mkdtemp()) / "test.db"

import finance  # noqa: E402
import messages  # noqa: E402
import ml  # noqa: E402
from app import create_app  # noqa: E402

TODAY = date(2026, 11, 15)


def tx(type_, amount, d="2026-11-02", category="Food & Dining"):
    return {"type": type_, "amount": amount, "date": d, "category": category}


class StatusRule(unittest.TestCase):
    def test_boundaries(self):
        self.assertEqual(finance.status_from_ratio(0.50), "high")      # 50% or more -> high
        self.assertEqual(finance.status_from_ratio(0.51), "high")
        self.assertEqual(finance.status_from_ratio(0.40), "low")       # 40% or lower -> low
        self.assertEqual(finance.status_from_ratio(0.39), "low")
        self.assertEqual(finance.status_from_ratio(0.45), "balanced")  # in between
        self.assertEqual(finance.status_from_ratio(0, has_deposits=False), "no_data")

    def test_summary_status(self):
        s = finance.compute_summary([tx("deposit", 10000), tx("expense", 5000)], TODAY)
        self.assertEqual(s["savings"]["status"], "high")
        s = finance.compute_summary([tx("deposit", 10000), tx("expense", 6000)], TODAY)
        self.assertEqual(s["savings"]["status"], "low")
        s = finance.compute_summary([tx("deposit", 10000), tx("expense", 5500)], TODAY)
        self.assertEqual(s["savings"]["status"], "balanced")

    def test_empty(self):
        s = finance.compute_summary([], TODAY)
        self.assertEqual(s["savings"]["status"], "no_data")
        self.assertIsNone(s["popup"])
        self.assertEqual(s["totals"]["available"], 0)


class Points(unittest.TestCase):
    def test_points_are_savings_minus_expenses(self):
        # D=20000, E=5000 -> savings 15000 -> points 15000-5000 = 10000
        s = finance.compute_summary([tx("deposit", 20000), tx("expense", 5000)], TODAY)
        self.assertEqual(s["level"]["points"], 10000)

    def test_points_never_negative(self):
        s = finance.compute_summary([tx("deposit", 1000), tx("expense", 900)], TODAY)
        self.assertEqual(s["level"]["points"], 0)

    def test_first_level_needs_5000(self):
        self.assertEqual(finance.level_info(4999)["level"], 1)
        self.assertEqual(finance.level_info(5000)["level"], 2)
        self.assertEqual(finance.level_info(5000)["points_to_next"], 10000)

    def test_progress_and_max_level(self):
        self.assertAlmostEqual(finance.level_info(2500)["progress"], 0.5)
        top = finance.level_info(10**7)
        self.assertEqual(top["level"], top["total_levels"])
        self.assertIsNone(top["next"])


class Budget(unittest.TestCase):
    def test_monthly_allowance(self):
        s = finance.compute_summary([tx("deposit", 10000), tx("expense", 2000)], TODAY)
        m = s["month"]
        self.assertEqual(m["allowance"], 5000)      # 50% of the month's income
        self.assertEqual(m["remaining"], 3000)
        self.assertEqual(m["days_left"], 16)        # 15th..30th of November
        self.assertEqual(m["daily_limit"], round(3000 / 16, 2))
        self.assertFalse(m["overspent"])

    def test_overspent(self):
        s = finance.compute_summary([tx("deposit", 10000), tx("expense", 5500)], TODAY)
        self.assertTrue(s["month"]["overspent"])
        self.assertEqual(s["month"]["remaining"], 0)

    def test_investment_is_not_expense(self):
        s = finance.compute_summary([tx("deposit", 10000), tx("investment", 3000)], TODAY)
        self.assertEqual(s["totals"]["expenses"], 0)
        self.assertEqual(s["totals"]["available"], 10000)
        self.assertEqual(s["totals"]["cash"], 7000)
        self.assertEqual(s["savings"]["status"], "high")


class HinglishPopups(unittest.TestCase):
    def test_low_and_high_messages(self):
        low = messages.status_popup("low", 30)
        high = messages.status_popup("high", 70)
        self.assertEqual(low["kind"], "low")
        self.assertIn("30%", low["message"])
        self.assertEqual(high["kind"], "high")
        self.assertIn("70%", high["message"])

    def test_inr_format(self):
        self.assertEqual(messages.inr(1234567), "₹12,34,567")
        self.assertEqual(messages.inr(999), "₹999")


class MachineLearning(unittest.TestCase):
    def test_category_known_words(self):
        for text, cat in [("chai", "Food & Dining"), ("uber ride", "Transport"), ("netflix", "Entertainment"),
                          ("electricity bill", "Bills & Recharge"), ("medicine", "Health")]:
            self.assertEqual(ml.predict_category(text)["category"], cat, text)

    def test_low_confidence_falls_back(self):
        r = ml.predict_category("zzzqqq")
        self.assertIn(r["category"], config.CATEGORIES)
        self.assertEqual(ml.predict_category("")["category"], "Other")

    def test_forecast(self):
        self.assertIsNone(ml.forecast_next_month([]))
        self.assertEqual(ml.forecast_next_month([100, 200])["method"], "average")
        f = ml.forecast_next_month([1000, 1100, 1200, 1300])
        self.assertEqual(f["method"], "ridge_trend")
        self.assertAlmostEqual(f["value"], 1400, delta=15)  # light Ridge shrinkage allowed

    def test_anomaly(self):
        history = [100, 120, 90, 110, 105, 95, 130, 100]
        self.assertTrue(ml.is_anomalous(5000, history))
        self.assertFalse(ml.is_anomalous(125, history))
        self.assertFalse(ml.is_anomalous(5000, [100, 100]))  # not enough history


class Api(unittest.TestCase):
    def setUp(self):
        self.client = create_app().test_client()

    def register(self, name="u1"):
        return self.client.post("/api/register", json={"username": name, "password": "secret1", "name": "Test"})

    def test_auth_required(self):
        self.assertEqual(self.client.get("/api/dashboard").status_code, 401)
        self.assertIsNone(self.client.get("/api/me").get_json()["user"])  # 200 with no user

    def test_register_duplicate_and_validation(self):
        self.assertEqual(self.register("dupuser").status_code, 201)
        self.assertEqual(self.register("dupuser").status_code, 409)
        bad = self.client.post("/api/register", json={"username": "a", "password": "secret1"})
        self.assertEqual(bad.status_code, 400)
        short = self.client.post("/api/register", json={"username": "okname", "password": "123"})
        self.assertEqual(short.status_code, 400)

    def test_login_wrong_password(self):
        self.register("loginuser")
        self.client.post("/api/logout")
        r = self.client.post("/api/login", json={"username": "loginuser", "password": "nope"})
        self.assertEqual(r.status_code, 401)
        r = self.client.post("/api/login", json={"username": "loginuser", "password": "secret1"})
        self.assertEqual(r.status_code, 200)

    def test_input_validation(self):
        self.register("valuser")
        bad = [
            {"type": "gift", "amount": 10},
            {"type": "deposit", "amount": -5},
            {"type": "deposit", "amount": "abc"},
            {"type": "deposit", "amount": True},
            {"type": "deposit", "amount": 100, "date": "not-a-date"},
            {"type": "deposit", "amount": 100, "date": (date.today() + timedelta(days=2)).isoformat()},
            {"type": "expense", "amount": 100},
            {"type": "expense", "amount": 100, "category": "Nonsense"},
        ]
        for body in bad:
            self.assertEqual(self.client.post("/api/transactions", json=body).status_code, 400, body)

    def test_low_popup_flow(self):
        self.register("flowuser")
        self.client.post("/api/transactions", json={"type": "deposit", "amount": 10000})
        r = self.client.post("/api/transactions", json={"type": "expense", "amount": 6500, "description": "amazon shirt"})
        data = r.get_json()
        kinds = [p["kind"] for p in data["popups"]]
        self.assertIn("low", kinds)
        self.assertEqual(data["transaction"]["category"], "Shopping")
        self.assertEqual(data["dashboard"]["savings"]["status"], "low")

    def test_high_popup_and_levelup(self):
        self.register("lvluser")
        r = self.client.post("/api/transactions", json={"type": "deposit", "amount": 20000})
        self.assertIn("levelup", [p["kind"] for p in r.get_json()["popups"]])  # 20000 points -> level 3
        r = self.client.post("/api/transactions", json={"type": "expense", "amount": 100, "description": "chai"})
        self.assertIn("high", [p["kind"] for p in r.get_json()["popups"]])

    def test_users_are_isolated_and_delete(self):
        self.register("isoA")
        t = self.client.post("/api/transactions", json={"type": "deposit", "amount": 500}).get_json()["transaction"]
        other = create_app().test_client()
        other.post("/api/register", json={"username": "isoB", "password": "secret1"})
        self.assertEqual(other.delete(f"/api/transactions/{t['id']}").status_code, 404)
        self.assertEqual(self.client.delete(f"/api/transactions/{t['id']}").status_code, 200)

    def test_categorize_and_surprise(self):
        self.register("miscuser")
        self.assertEqual(self.client.post("/api/categorize", json={"description": "metro"}).get_json()["category"], "Transport")
        self.assertIn("message", self.client.get("/api/surprise").get_json())


if __name__ == "__main__":
    unittest.main()
