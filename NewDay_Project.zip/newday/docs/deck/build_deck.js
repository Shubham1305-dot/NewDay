// Builds NewDay_Presentation.pptx  (run: node build_deck.js)
const pptxgen = require("pptxgenjs");
const SK = "/root/.claude/skills/synced/e7bc6f0b-8955-42ad-a342-1330d0d3532d_eb7a974c-e16b-4113-bcbd-f28de6584f26/pptx";
const { applyTheme } = require(SK + "/scripts/apply_theme.js");

const THEME = {
  name: "NewDay Dawn",
  headFontFace: "Cambria",
  bodyFontFace: "Calibri",
  colors: {
    dk1: "14213D", lt1: "FFFFFF", dk2: "2B3A5C", lt2: "EDF1F7",
    accent1: "F5A524", accent2: "1F9D8A", accent3: "E5484D",
    accent4: "2C3470", accent5: "7A4B00", accent6: "5B6678",
    hlink: "2C3470", folHlink: "5B6678",
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9"; // 10 x 5.625 in
pres.title = "NewDay: ML-based personal finance manager";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;
const IMG = (f) => __dirname + "/" + f;
const SHOT = (f) => __dirname + "/../screenshots/" + f;

// ---------------- layouts ----------------
pres.defineSlideMaster({
  title: "TITLE_DARK",
  background: { color: "14213D" },
  objects: [],
  slideNumber: undefined,
  // placeholders
  ...{},
});
pres.defineSlideMaster({
  title: "CONTENT",
  background: { color: "FFFFFF" },
  objects: [
    { text: { text: "NewDay", options: { x: 0.5, y: 5.22, w: 2, h: 0.28, fontSize: 10, color: C.accent6, margin: 0, isTextBox: true } } },
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.32, w: 9, h: 0.85, fontSize: 34, bold: true, color: C.text1, valign: "middle", align: "left", margin: 0 }, text: "" } },
  ],
  slideNumber: { x: 9.0, y: 5.22, w: 0.5, h: 0.28, fontSize: 10, color: C.accent6, align: "right", margin: 0 },
});
pres.defineSlideMaster({
  title: "CLOSE_DARK",
  background: { color: "14213D" },
  objects: [],
});

const shadow = () => ({ type: "outer", color: "000000", blur: 8, offset: 2, angle: 90, opacity: 0.12 });
const NOTE = (s, t) => s.addNotes(t);

function content(title, section, notes) {
  const s = pres.addSlide({ masterName: "CONTENT", sectionTitle: section });
  s.addText(title, { placeholder: "title" });
  if (notes) s.addNotes(notes);
  return s;
}

// ================= 1. Title =================
pres.addSection({ title: "Introduction" });
{
  const s = pres.addSlide({ masterName: "TITLE_DARK", sectionTitle: "Introduction" });
  s.addShape(pres.ShapeType.ellipse, { x: 3.0, y: 3.8, w: 4.0, h: 4.0, fill: { color: C.accent1 }, line: { type: "none" }, objectName: "Sun" });
  s.addText("Project presentation", { x: 0.7, y: 0.7, w: 6, h: 0.35, fontSize: 14, color: C.background1, margin: 0, isTextBox: true, transparency: 15 });
  s.addText("NewDay", { x: 0.7, y: 1.15, w: 8, h: 1.3, fontFace: "Cambria", fontSize: 66, bold: true, color: C.background1, margin: 0, isTextBox: true, objectName: "Title" });
  s.addText("A machine-learning money tracker that warns in Hinglish and rewards saving with levels", { x: 0.7, y: 2.45, w: 6.4, h: 0.9, fontSize: 20, color: C.background1, margin: 0, isTextBox: true, valign: "top" });
  s.addText("Har din ek naya din.", { x: 0.7, y: 3.45, w: 5, h: 0.4, fontSize: 18, italic: true, color: C.accent1, margin: 0, isTextBox: true });
  s.addNotes("Introduce NewDay: a personal finance app that tracks deposits, expenses and investments, tells you how much you can spend this month, warns in Hinglish when savings run low, and turns saving into levels.");
}

// ================= 2. Problem =================
{
  const s = content("Why tracking alone fails", "Introduction",
    "Most trackers only list what was spent. They do not warn in the moment, and they give no reason to keep going. NewDay answers three questions at any time.");
  s.addText("People run short before the month ends, and small daily leaks go unnoticed. NewDay answers three questions:", { x: 0.5, y: 1.25, w: 9, h: 0.7, fontSize: 16, color: C.text2, margin: 0, isTextBox: true, valign: "top" });
  const cards = [
    ["How much do I have?", "Deposited, spent, invested and available, always up to date.", C.accent2],
    ["How much can I spend this month?", "A monthly and a daily limit that keeps savings healthy.", C.accent1],
    ["Am I doing well?", "A savings gauge, Hinglish popups and a level that grows.", C.accent4],
  ];
  cards.forEach(([h, b, col], i) => {
    const x = 0.5 + i * 3.1;
    s.addShape(pres.ShapeType.roundRect, { x, y: 2.15, w: 2.8, h: 2.7, rectRadius: 0.12, fill: { color: col, transparency: 88 }, line: { type: "none" }, objectName: "Question card " + (i + 1) });
    s.addText(h, { x: x + 0.2, y: 2.35, w: 2.4, h: 0.95, fontSize: 18, bold: true, color: C.text1, margin: 0, isTextBox: true, valign: "top" });
    s.addText(b, { x: x + 0.2, y: 3.4, w: 2.4, h: 1.3, fontSize: 14, color: C.text2, margin: 0, isTextBox: true, valign: "top" });
  });
}

// ================= 3. Features =================
{
  const s = content("What NewDay does", "Introduction",
    "Six features: tracking, the monthly limit, Hinglish popups, levels, smart categories, and forecast with large-expense alerts.");
  const f = [
    ["Track money", "Deposits, expenses and investments per user", C.accent2],
    ["Monthly limit", "How much you can spend, and per day", C.accent1],
    ["Hinglish popups", "Stop at 40% or less, relax at 50% or more", C.accent3],
    ["Points and levels", "Points = savings − expenses", C.accent4],
    ["Smart categories", "ML reads \"chai\" and files it under Food", C.accent2],
    ["Forecast and alerts", "Next-month spend, large-expense warning", C.accent1],
  ];
  f.forEach(([h, b, col], i) => {
    const x = 0.5 + (i % 3) * 3.1, y = 1.4 + Math.floor(i / 3) * 1.9;
    s.addShape(pres.ShapeType.roundRect, { x, y, w: 2.8, h: 1.7, rectRadius: 0.12, fill: { color: col, transparency: 88 }, line: { type: "none" }, objectName: "Feature card " + (i + 1) });
    s.addText(h, { x: x + 0.2, y: y + 0.18, w: 2.4, h: 0.4, fontSize: 18, bold: true, color: C.text1, margin: 0, isTextBox: true });
    s.addText(b, { x: x + 0.2, y: y + 0.65, w: 2.4, h: 0.9, fontSize: 14, color: C.text2, margin: 0, isTextBox: true, valign: "top" });
  });
}

// ================= 4. Architecture =================
pres.addSection({ title: "Design" });
{
  const s = content("How the pieces fit", "Design",
    "The browser talks to one Flask API. The API uses the finance rules, the ML models and the Hinglish messages, and stores data in SQLite. The classifier is trained ahead of time and loaded when first needed.");
  const box = (x, y, w, name, sub, main) => {
    s.addShape(pres.ShapeType.roundRect, { x, y, w, h: 0.95, rectRadius: 0.1,
      fill: main ? { color: C.accent1, transparency: 80 } : { color: C.lightBg || C.background2 },
      line: { color: main ? C.accent1 : C.accent6, width: main ? 2 : 1 }, objectName: name });
    s.addText([{ text: name, options: { bold: true, fontSize: 16, color: C.text1, breakLine: true } }, { text: sub, options: { fontSize: 12, color: C.accent6 } }],
      { x, y, w, h: 0.95, align: "center", valign: "middle", margin: 0.05, isTextBox: true });
  };
  box(0.5, 1.45, 2.5, "Browser", "HTML, CSS, JavaScript", false);
  box(3.75, 1.45, 2.5, "Flask API", "app.py", true);
  box(7.0, 1.45, 2.5, "SQLite", "users, transactions", false);
  const ln = (x, y, w, h, both) => s.addShape(pres.ShapeType.line, { x, y, w, h, line: { color: C.accent6, width: 1.5, beginArrowType: both ? "triangle" : undefined, endArrowType: "triangle" } });
  ln(3.0, 1.925, 0.75, 0, true);
  ln(6.25, 1.925, 0.75, 0, true);
  s.addShape(pres.ShapeType.line, { x: 5.0, y: 2.4, w: 0, h: 0.4, line: { color: C.accent6, width: 1.5 } });
  s.addShape(pres.ShapeType.line, { x: 1.75, y: 2.8, w: 6.5, h: 0, line: { color: C.accent6, width: 1.5 } });
  [1.75, 5.0, 8.25].forEach((cx) => s.addShape(pres.ShapeType.line, { x: cx, y: 2.8, w: 0, h: 0.4, line: { color: C.accent6, width: 1.5, endArrowType: "triangle" } }));
  box(0.5, 3.25, 2.5, "Finance rules", "status, limit, points", false);
  box(3.75, 3.25, 2.5, "ML models", "category, forecast, alert", false);
  box(7.0, 3.25, 2.5, "Hinglish messages", "popup text", false);
  s.addText("The category model is trained ahead of time and loaded the first time it is needed.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 14, color: C.accent6, margin: 0, isTextBox: true });
}

// ================= 5. The 40/50 rule =================
{
  const s = content("The 40% and 50% rule", "Design",
    "Savings ratio is deposits minus expenses, divided by deposits. 50 percent or more is high, 40 percent or less is low. The brief did not cover 40 to 50, so that band is treated as balanced with a neutral message.");
  s.addText("Savings ratio = (deposited − expenses) ÷ deposited", { x: 0.5, y: 1.3, w: 9, h: 0.4, fontSize: 18, color: C.text2, margin: 0, isTextBox: true });
  const X0 = 0.5, W = 9;
  s.addShape(pres.ShapeType.rect, { x: X0, y: 2.0, w: W * 0.4, h: 0.9, fill: { color: C.accent3, transparency: 80 }, line: { type: "none" }, objectName: "Low zone" });
  s.addShape(pres.ShapeType.rect, { x: X0 + W * 0.4, y: 2.0, w: W * 0.1, h: 0.9, fill: { color: C.accent1, transparency: 70 }, line: { type: "none" }, objectName: "Balanced zone" });
  s.addShape(pres.ShapeType.rect, { x: X0 + W * 0.5, y: 2.0, w: W * 0.5, h: 0.9, fill: { color: C.accent2, transparency: 80 }, line: { type: "none" }, objectName: "High zone" });
  s.addText("LOW: 40% or less", { x: X0, y: 2.0, w: W * 0.4, h: 0.9, fontSize: 18, bold: true, color: C.accent3, align: "center", valign: "middle", margin: 0, isTextBox: true });
  s.addText("in between", { x: X0 + W * 0.4, y: 2.0, w: W * 0.1, h: 0.9, fontSize: 11, bold: true, color: C.accent5, align: "center", valign: "middle", margin: 0, isTextBox: true });
  s.addText("HIGH: 50% or more", { x: X0 + W * 0.5, y: 2.0, w: W * 0.5, h: 0.9, fontSize: 18, bold: true, color: C.accent2, align: "center", valign: "middle", margin: 0, isTextBox: true });
  s.addText("0%", { x: X0, y: 2.95, w: 0.8, h: 0.3, fontSize: 12, color: C.accent6, margin: 0, isTextBox: true });
  s.addText("40%", { x: X0 + W * 0.4 - 0.4, y: 2.95, w: 0.8, h: 0.3, fontSize: 12, color: C.accent6, align: "center", margin: 0, isTextBox: true });
  s.addText("50%", { x: X0 + W * 0.5 - 0.4, y: 3.25, w: 0.8, h: 0.3, fontSize: 12, color: C.accent6, align: "center", margin: 0, isTextBox: true });
  s.addText("100% of deposits kept as savings", { x: X0 + W - 3.2, y: 2.95, w: 3.2, h: 0.3, fontSize: 12, color: C.accent6, align: "right", margin: 0, isTextBox: true });
  s.addShape(pres.ShapeType.roundRect, { x: 0.5, y: 3.8, w: 4.4, h: 1.15, rectRadius: 0.1, fill: { color: C.accent3, transparency: 88 }, line: { type: "none" }, objectName: "Low example" });
  s.addText([{ text: "₹10,000 in, ₹6,500 out", options: { bold: true, breakLine: true } }, { text: "35% saved: popup says stop spending", options: {} }], { x: 0.7, y: 3.8, w: 4.0, h: 1.15, fontSize: 14, color: C.text1, valign: "middle", margin: 0, isTextBox: true });
  s.addShape(pres.ShapeType.roundRect, { x: 5.1, y: 3.8, w: 4.4, h: 1.15, rectRadius: 0.1, fill: { color: C.accent2, transparency: 88 }, line: { type: "none" }, objectName: "High example" });
  s.addText([{ text: "₹20,000 in, ₹5,000 out", options: { bold: true, breakLine: true } }, { text: "75% saved: popup says spend a little more", options: {} }], { x: 5.3, y: 3.8, w: 4.0, h: 1.15, fontSize: 14, color: C.text1, valign: "middle", margin: 0, isTextBox: true });
}

// ================= 6. Monthly limit =================
{
  const s = content("How much can I spend?", "Design",
    "The user can spend up to 50 percent of the month's income and still stay in the high zone. The limit is that amount minus what is already spent, capped by cash. Example: 10,000 income and 2,000 spent leaves 3,000, which over 16 days is 187.50 a day.");
  s.addText("Spend up to 50% of this month's income and you stay in the high zone.", { x: 0.5, y: 1.3, w: 9, h: 0.6, fontSize: 18, color: C.text2, margin: 0, isTextBox: true, valign: "top" });
  const stat = (x, big, small, col) => {
    s.addShape(pres.ShapeType.roundRect, { x, y: 2.1, w: 2.8, h: 1.9, rectRadius: 0.12, fill: { color: col, transparency: 88 }, line: { type: "none" }, objectName: "Stat " + big });
    s.addText(big, { x: x + 0.1, y: 2.3, w: 2.6, h: 0.9, fontSize: 40, bold: true, fontFace: "Cambria", color: C.text1, align: "center", margin: 0, isTextBox: true });
    s.addText(small, { x: x + 0.15, y: 3.2, w: 2.5, h: 0.65, fontSize: 14, color: C.text2, align: "center", valign: "top", margin: 0, isTextBox: true });
  };
  stat(0.5, "₹5,000", "allowance: 50% of ₹10,000 income", C.accent4);
  stat(3.6, "₹3,000", "left after ₹2,000 already spent", C.accent2);
  stat(6.7, "₹187.50", "a day, for the 16 days left", C.accent1);
  s.addText("remaining = min( cash , 50% × income − spent this month )", { x: 0.5, y: 4.35, w: 9, h: 0.5, fontSize: 16, color: C.text1, fontFace: "Courier New", align: "center", margin: 0, isTextBox: true });
}

// ================= 7. Levels =================
{
  const s = content("Points and levels", "Design",
    "Points are savings minus expenses. The first level needs 5,000 points to cross. Level names, titles, thresholds and surprises live in levels.json and can be replaced with your own names without changing code. Points are live, so a big expense can lower the level.");
  s.addText("Points = savings − expenses", { x: 0.5, y: 1.3, w: 4.2, h: 0.5, fontSize: 22, bold: true, color: C.text1, margin: 0, isTextBox: true });
  s.addText([
    { text: "5,000 points to cross the first level", options: { bullet: true, breakLine: true } },
    { text: "8 levels, each with a name, a title and a surprise", options: { bullet: true, breakLine: true } },
    { text: "Names and thresholds sit in one file, ready for your own names", options: { bullet: true, breakLine: true } },
    { text: "Points are live: a big expense can drop a level", options: { bullet: true } },
  ], { x: 0.5, y: 1.95, w: 4.2, h: 2.9, fontSize: 16, color: C.text2, paraSpaceAfter: 10, margin: 0, isTextBox: true, valign: "top" });
  s.addChart(pres.charts.BAR, [{ name: "Points needed", labels: ["L1", "L2", "L3", "L4", "L5", "L6", "L7", "L8"], values: [0, 5000, 15000, 30000, 50000, 80000, 120000, 200000] }], {
    x: 5.0, y: 1.2, w: 4.6, h: 3.8, barDir: "bar", chartColors: ["F5A524"],
    showTitle: true, title: "Points needed to start each level", titleFontSize: 14, titleColor: "14213D", titleFontFace: "+mn-lt",
    showValue: true, dataLabelPosition: "outEnd", dataLabelFontSize: 11, dataLabelColor: "14213D", dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "#,##0",
    catAxisLabelColor: "5B6678", catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false, valAxisMaxVal: 250000,
  });
}

// ================= 8. Hinglish popups =================
{
  const s = content("Hinglish nudges", "Design",
    "Each popup type has several messages and one is picked at random. The low popup tells you to stop spending, the high popup says a little more is fine, and a large-expense popup asks whether it was really needed. Show the screenshot on the right: it is the real popup after adding a 4,500 rupee dinner.");
  const pop = (y, tag, msg, col, tagCol) => {
    s.addShape(pres.ShapeType.roundRect, { x: 0.5, y, w: 5.0, h: 1.2, rectRadius: 0.1, fill: { color: col, transparency: 86 }, line: { type: "none" }, objectName: tag + " popup" });
    s.addText([{ text: tag, options: { bold: true, fontSize: 12, color: tagCol || col, breakLine: true } }, { text: msg, options: { fontSize: 14, color: C.text1 } }],
      { x: 0.7, y, w: 4.6, h: 1.2, valign: "middle", margin: 0, isTextBox: true });
  };
  pop(1.3, "LOW SAVINGS", "Yaar, paisa kaafi kam bach gaya hai, sirf 38% bachat bachi hai. Ab kharche rok de!", C.accent3);
  pop(2.65, "HIGH SAVINGS", "Wah! 75% bachat, tu toh champion nikla. Thoda sa kharcha kar sakta hai!", C.accent2);
  pop(4.0, "LARGE EXPENSE", "Hmm, ₹4,500 ka kharcha tere normal se kaafi bada lag raha hai. Sach mein zaroori tha?", C.accent1, C.accent5);
  s.addImage({ path: IMG("popup.png"), x: 5.8, y: 1.3, w: 3.7, h: 2.72, altText: "Large-expense popup in the app", objectName: "Popup screenshot", shadow: shadow() });
  s.addText("The real popup after adding a ₹4,500 dinner.", { x: 5.8, y: 4.1, w: 3.7, h: 0.5, fontSize: 12, color: C.accent6, margin: 0, isTextBox: true, valign: "top" });
}

// ================= 9. ML parts =================
pres.addSection({ title: "Machine learning" });
{
  const s = content("Three ML parts", "Machine learning",
    "One: the category classifier uses TF-IDF on character n-grams and a calibrated linear SVM, and falls back to Other when unsure. Two: the forecast uses ridge regression on monthly totals, or an average with under three finished months. Three: large-expense detection uses an isolation forest with 30 or more expenses, or a median and MAD rule before that.");
  const cols = [
    ["Category classifier", "TF-IDF on character n-grams plus a calibrated Linear SVM. 10 categories. Falls back to Other when unsure.", C.accent2],
    ["Spending forecast", "Ridge regression on monthly totals. A plain average when there are under 3 finished months.", C.accent1],
    ["Large-expense alert", "Isolation Forest with 30+ expenses; a median and MAD rule before that.", C.accent4],
  ];
  cols.forEach(([h, b, col], i) => {
    const x = 0.5 + i * 3.1;
    s.addShape(pres.ShapeType.roundRect, { x, y: 1.4, w: 2.8, h: 3.0, rectRadius: 0.12, fill: { color: col, transparency: 88 }, line: { type: "none" }, objectName: "ML card " + (i + 1) });
    s.addText(h, { x: x + 0.2, y: 1.6, w: 2.4, h: 0.8, fontSize: 20, bold: true, color: C.text1, margin: 0, isTextBox: true, valign: "top" });
    s.addText(b, { x: x + 0.2, y: 2.5, w: 2.4, h: 2.1, fontSize: 14, color: C.text2, margin: 0, isTextBox: true, valign: "top" });
  });
}

// ================= 10. Model results =================
{
  const s = content("Honest ML results", "Machine learning",
    "Three models were compared. On words seen in training they all score about 99 percent. On keywords held out of training, only about 30 percent. We chose the calibrated Linear SVM because it had the best macro F1 on unseen words. The data is synthetic, so real accuracy will be lower. The app falls back to Other when unsure and lets the user pick.");
  s.addChart(pres.charts.BAR, [
    { name: "Seen words", labels: ["Logistic Regression", "Naive Bayes", "Linear SVM"], values: [99.3, 99.2, 99.3] },
    { name: "Unseen words", labels: ["Logistic Regression", "Naive Bayes", "Linear SVM"], values: [29.6, 31.4, 32.5] },
  ], {
    x: 0.5, y: 1.25, w: 5.6, h: 3.8, barDir: "col", barGrouping: "clustered", chartColors: ["14213D", "F5A524"],
    showTitle: true, title: "Accuracy (%) on seen vs unseen words", titleFontSize: 14, titleColor: "14213D", titleFontFace: "+mn-lt",
    showValue: true, dataLabelPosition: "outEnd", dataLabelFontSize: 11, dataLabelColor: "14213D", dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0.0",
    catAxisLabelColor: "5B6678", catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt",
    valAxisHidden: true, valAxisMaxVal: 115, valAxisMinVal: 0, valGridLine: { style: "none" }, catGridLine: { style: "none" },
    showLegend: true, legendPos: "b", legendFontSize: 12, legendColor: "5B6678", legendFontFace: "+mn-lt",
  });
  s.addShape(pres.ShapeType.roundRect, { x: 6.4, y: 1.35, w: 3.1, h: 3.0, rectRadius: 0.12, fill: { color: C.accent3, transparency: 88 }, line: { type: "none" }, objectName: "Honest callout" });
  s.addText([
    { text: "About 30%", options: { fontSize: 32, bold: true, fontFace: "Cambria", color: C.accent3, breakLine: true } },
    { text: "on words it has never seen", options: { fontSize: 14, color: C.text2, breakLine: true } },
    { text: " ", options: { fontSize: 8, breakLine: true } },
    { text: "So the app asks the user to confirm uncertain categories, and next learns from their corrections.", options: { fontSize: 14, color: C.text1 } },
  ], { x: 6.6, y: 1.55, w: 2.7, h: 3.2, margin: 0, isTextBox: true, valign: "top" });
}

// ================= 11. Dashboard screenshots =================
pres.addSection({ title: "Results" });
{
  const s = content("The dashboard in action", "Results",
    "Left: the demo account with 75 percent saved, 3,003 rupees to spend and Level 2. Right: after a 4,500 rupee dinner, savings drop to 38 percent, the gauge turns to the low zone, the limit falls to zero, and the level falls to Level 1 because points are live.");
  const W = 4.3, H = W * 880 / 1280;
  s.addImage({ path: IMG("before.png"), x: 0.5, y: 1.4, w: W, h: H, altText: "Dashboard with 75% saved", objectName: "Dashboard before", shadow: shadow() });
  s.addImage({ path: IMG("after.png"), x: 5.2, y: 1.4, w: W, h: H, altText: "Dashboard with 38% saved", objectName: "Dashboard after", shadow: shadow() });
  s.addText([{ text: "Before: ", options: { bold: true, color: C.accent2 } }, { text: "75% saved, ₹3,003 to spend, Level 2", options: {} }], { x: 0.5, y: 4.5, w: 4.3, h: 0.5, fontSize: 14, color: C.text1, margin: 0, isTextBox: true, valign: "top" });
  s.addText([{ text: "After ₹4,500 dinner: ", options: { bold: true, color: C.accent3 } }, { text: "38% saved, ₹0, Level 1", options: {} }], { x: 5.2, y: 4.5, w: 4.3, h: 0.5, fontSize: 14, color: C.text1, margin: 0, isTextBox: true, valign: "top" });
}

// ================= 12. Testing =================
{
  const s = content("Tested end to end", "Results",
    "24 automated tests pass: status rule 3, points and levels 4, monthly budget 3, Hinglish popups 2, machine learning 4, API 8. A live browser run with the demo account showed every rule working, with no JavaScript errors and no sideways scroll on a phone-width screen.");
  s.addShape(pres.ShapeType.roundRect, { x: 0.5, y: 1.35, w: 3.2, h: 3.5, rectRadius: 0.12, fill: { color: C.accent2, transparency: 88 }, line: { type: "none" }, objectName: "Tests stat" });
  s.addText("24", { x: 0.5, y: 1.55, w: 3.2, h: 1.4, fontSize: 80, bold: true, fontFace: "Cambria", color: C.accent2, align: "center", margin: 0, isTextBox: true });
  s.addText("automated tests, all passing", { x: 0.7, y: 3.0, w: 2.8, h: 0.5, fontSize: 16, color: C.text1, align: "center", margin: 0, isTextBox: true });
  s.addText("Plus a live browser run: no errors, no sideways scroll on a phone", { x: 0.7, y: 3.6, w: 2.8, h: 1.0, fontSize: 14, color: C.text2, align: "center", valign: "top", margin: 0, isTextBox: true });
  s.addChart(pres.charts.BAR, [{ name: "Tests", labels: ["API", "Points and levels", "Machine learning", "Status rule", "Monthly budget", "Hinglish popups"], values: [8, 4, 4, 3, 3, 2] }], {
    x: 4.0, y: 1.25, w: 5.5, h: 3.7, barDir: "bar", chartColors: ["1F9D8A"],
    showTitle: true, title: "Tests by area", titleFontSize: 14, titleColor: "14213D", titleFontFace: "+mn-lt",
    showValue: true, dataLabelPosition: "outEnd", dataLabelFontSize: 12, dataLabelColor: "14213D", dataLabelFontFace: "+mn-lt",
    catAxisLabelColor: "14213D", catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMaxVal: 10, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
  });
}

// ================= 13. Limits + future =================
pres.addSection({ title: "Close" });
{
  const s = content("Limits and next steps", "Close",
    "Be upfront about limits: synthetic training data, forecast needs a finished month, and no CSRF token, email verification or password reset. Next steps: learn from user corrections, better text understanding, per-category budgets, statement import, and a phone app with notifications.");
  const col = (x, head, items, c) => {
    s.addShape(pres.ShapeType.roundRect, { x, y: 1.35, w: 4.4, h: 3.1, rectRadius: 0.12, fill: { color: c, transparency: 88 }, line: { type: "none" }, objectName: head });
    s.addText(head, { x: x + 0.25, y: 1.5, w: 3.9, h: 0.45, fontSize: 20, bold: true, color: C.text1, margin: 0, isTextBox: true });
    s.addText(items.map((t, i) => ({ text: t, options: { bullet: true, breakLine: i < items.length - 1 } })),
      { x: x + 0.25, y: 2.05, w: 3.9, h: 2.7, fontSize: 14, color: C.text2, paraSpaceAfter: 6, margin: 0, isTextBox: true, valign: "top" });
  };
  col(0.5, "Limits today", ["Trained on synthetic data: weak on unseen words", "Forecast needs one finished month", "No CSRF token, email check or password reset", "Level names are placeholders until yours go in"], C.accent3);
  col(5.1, "Next steps", ["Learn from user category corrections", "Word embeddings for unseen words", "Per-category budgets and recurring entries", "Import bank or UPI statements", "Installable phone app with notifications"], C.accent2);
}

// ================= 14. Close =================
{
  const s = pres.addSlide({ masterName: "CLOSE_DARK", sectionTitle: "Close" });
  s.addShape(pres.ShapeType.ellipse, { x: 3.0, y: 3.6, w: 4.0, h: 4.0, fill: { color: C.accent1 }, line: { type: "none" }, objectName: "Sun" });
  s.addText("Thank you", { x: 0.7, y: 0.9, w: 8.6, h: 1.1, fontFace: "Cambria", fontSize: 54, bold: true, color: C.background1, margin: 0, isTextBox: true });
  s.addText("NewDay: know what you have, spend what you can, level up as you save.", { x: 0.7, y: 2.0, w: 7.5, h: 0.9, fontSize: 20, color: C.background1, margin: 0, isTextBox: true, valign: "top" });
  s.addText("Har din ek naya din.", { x: 0.7, y: 2.95, w: 5, h: 0.4, fontSize: 18, italic: true, color: C.accent1, margin: 0, isTextBox: true });
  s.addNotes("Close. To run: pip install -r requirements.txt, then python app.py from the backend folder, and open http://127.0.0.1:5000. Demo login: demo / demo123.");
}

(async () => {
  const out = __dirname + "/../NewDay_Presentation.pptx";
  await pres.writeFile({ fileName: out });
  await applyTheme(out, THEME);
  console.log("written", out);
})();
