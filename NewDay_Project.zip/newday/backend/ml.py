"""The three ML pieces of NewDay.

1. predict_category    - TF-IDF char n-grams + a linear classifier (trained in train_model.py)
2. forecast_next_month - Ridge regression on monthly expense totals (average when history is short)
3. is_anomalous        - IsolationForest on log-amounts (robust z-score when history is short)
"""
import numpy as np
import joblib
from sklearn.ensemble import IsolationForest
from sklearn.linear_model import Ridge

import config

_model = None


# ---- 1. Expense category classifier -------------------------------------
def load_model():
    global _model
    if _model is None:
        path = config.MODEL_DIR / "category_model.joblib"
        if not path.exists():
            import train_model
            train_model.train_and_save()
        _model = joblib.load(path)
    return _model


def predict_category(text):
    text = (text or "").strip().lower()
    if not text:
        return {"category": "Other", "confidence": 0.0, "low_confidence": True}
    model = load_model()
    proba = model.predict_proba([text])[0]
    i = int(np.argmax(proba))
    best, conf = str(model.classes_[i]), float(proba[i])
    if conf < config.MIN_CONFIDENCE:
        return {"category": "Other", "confidence": round(conf, 3), "low_confidence": True, "suggested": best}
    return {"category": best, "confidence": round(conf, 3), "low_confidence": False}


# ---- 2. Next-month spending forecast ------------------------------------
def forecast_next_month(monthly_expenses):
    """monthly_expenses: totals of past complete months, oldest first."""
    values = [float(v) for v in monthly_expenses][-6:]
    n = len(values)
    if n == 0:
        return None
    if n < 3:
        return {"value": round(sum(values) / n, 2), "method": "average", "months_used": n}
    x = np.arange(n).reshape(-1, 1)
    model = Ridge(alpha=0.1).fit(x, np.array(values))  # light shrinkage: stable but follows the trend
    pred = float(model.predict([[n]])[0])
    pred = min(max(pred, 0.0), max(values) * 1.5)  # keep the forecast sane
    return {"value": round(pred, 2), "method": "ridge_trend", "months_used": n}


# ---- 3. Unusually large expense detection -------------------------------
def is_anomalous(amount, history):
    """True if `amount` is unusually large compared with the user's past expenses."""
    hist = np.array([float(h) for h in history if h > 0])
    if len(hist) < 5:
        return False
    median = float(np.median(hist))
    if amount <= median * 1.5:  # only ever flag *large* expenses
        return False
    if len(hist) >= 30:
        forest = IsolationForest(n_estimators=100, contamination=0.05, random_state=0)
        forest.fit(np.log1p(hist).reshape(-1, 1))
        return bool(forest.predict([[np.log1p(amount)]])[0] == -1)
    mad = float(np.median(np.abs(hist - median))) or max(median * 0.1, 1.0)
    robust_z = 0.6745 * (amount - median) / mad
    return bool(robust_z > 3.5)
