import subprocess,json,re,sys
pdf=sys.argv[1]
n=int(re.search(r'Pages:\s+(\d+)',subprocess.check_output(['pdfinfo',pdf]).decode()).group(1))
P={}
heads=["1. ABSTRACT","2. BACKGROUND","3. SOFTWARE / HARDWARE USED","4. METHODOLOGY","5. EXPERIMENTAL RESULTS","6. CONCLUSION","7. REFERENCES"]
for p in range(4,n+1):  # skip cover/index/lists
    t=subprocess.check_output(['pdftotext','-f',str(p),'-l',str(p),'-layout',pdf,'-']).decode()
    for h in heads:
        if re.search(r'^\s*'+re.escape(h)+r'\s*$',t,re.M): P.setdefault(h,p)
    for i in range(1,9):
        if re.search(r'^\s*Table %d:'%i,t,re.M): P.setdefault('tab%d'%i,p)
        if re.search(r'^\s*Figure %d:'%i,t,re.M): P.setdefault('fig%d'%i,p)
json.dump(P,open('pages.json','w'),indent=1);print(P)
