// Builds NewDay_Project_Report_Bennett.docx following the Bennett University report format.
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell, Footer,
  AlignmentType, LevelFormat, WidthType, BorderStyle, ShadingType, PageNumber, VerticalAlign, TableLayoutType,
} = require("docx");

const HERE = __dirname;
const IMG = (f) => fs.readFileSync(path.join(HERE, "img", f));
const PAGES = fs.existsSync(path.join(HERE, "pages.json")) ? JSON.parse(fs.readFileSync(path.join(HERE, "pages.json"), "utf8")) : {};
const pg = (k) => (PAGES[k] !== undefined ? String(PAGES[k]) : "");

// ------------------------------------------------------------------ constants
const FONT = "Times New Roman";
const BODY_LINE = 360;       // 1.5 line spacing
const PARA_AFTER = 340;      // about 2.5 single lines between paragraphs (see README note)
const TEXT_W = 8335;         // A4 width 11906 - 1417 - 1417 - 737 gutter

const TITLE = "NewDay: A Machine Learning Based Personal Finance Manager with Hinglish Alerts and Level Rewards";
const STUDENT = { name: "SUBHAM", enroll: "S25CSEU1605" };
const FACULTY = "Sunakshi Singh";

// ------------------------------------------------------------------ helpers
const run = (t, o = {}) => new TextRun({ text: t, font: FONT, size: 24, ...o });
const body = (content, opts = {}) =>
  new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: BODY_LINE, after: PARA_AFTER, before: 0 },
    ...opts,
    children: Array.isArray(content) ? content : [run(content)],
  });
const h1 = (t, opts = {}) =>
  new Paragraph({ style: "Heading1", children: [new TextRun({ text: t, font: FONT, size: 32, bold: true })], ...opts });
const h2 = (t) => new Paragraph({ style: "Heading2", children: [new TextRun({ text: t, font: FONT, size: 24, bold: true })] });
const bullets = (items) =>
  items.map((t, i) =>
    new Paragraph({
      numbering: { reference: "bullets", level: 0 },
      alignment: AlignmentType.JUSTIFIED,
      spacing: { line: BODY_LINE, after: i === items.length - 1 ? PARA_AFTER : 80 },
      children: [run(t)],
    }));
const caption = (label, text, where) =>
  new Paragraph({
    alignment: AlignmentType.CENTER,
    keepNext: where === "above",
    spacing: { line: BODY_LINE, before: where === "above" ? 60 : 60, after: where === "above" ? 100 : PARA_AFTER },
    children: [run(`${label}: `, { bold: true }), run(text)],
  });
const figure = (file, wPx, hPx, alt) =>
  new Paragraph({
    alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 60, after: 60 },
    children: [new ImageRun({ type: "png", data: IMG(file), transformation: { width: wPx, height: hPx }, altText: { title: alt, description: alt, name: file } })],
  });

const thin = { style: BorderStyle.SINGLE, size: 4, color: "000000" };
const borders = { top: thin, bottom: thin, left: thin, right: thin };
function cell(text, w, { bold = false, fill, align = AlignmentType.LEFT, size = 22 } = {}) {
  const runs = Array.isArray(text) ? text : [new TextRun({ text: String(text), font: FONT, size, bold })];
  return new TableCell({
    borders, width: { size: w, type: WidthType.DXA }, verticalAlign: VerticalAlign.CENTER,
    shading: fill ? { type: ShadingType.CLEAR, fill, color: "auto" } : undefined,
    margins: { top: 50, bottom: 50, left: 90, right: 90 },
    children: [new Paragraph({ alignment: align, spacing: { line: 240, after: 0, before: 0 }, children: runs })],
  });
}
function table(widths, header, rows, { aligns = [], boldCells = [], size = 22 } = {}) {
  const total = widths.reduce((a, b) => a + b, 0);
  const hdr = new TableRow({ tableHeader: true, cantSplit: true,
    children: header.map((t, i) => cell(t, widths[i], { bold: true, fill: "D9D9D9", size, align: aligns[i] || AlignmentType.LEFT })) });
  const rs = rows.map((r, ri) => new TableRow({ cantSplit: true,
    children: r.map((t, i) => cell(t, widths[i], { size, align: aligns[i] || AlignmentType.LEFT, bold: boldCells.some(([a, b]) => a === ri && b === i) })) }));
  return new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: widths, layout: TableLayoutType.FIXED, alignment: AlignmentType.CENTER, rows: [hdr, ...rs] });
}
const spacer = () => new Paragraph({ spacing: { line: 240, after: 200, before: 0 }, children: [] });
const C = AlignmentType.CENTER, R = AlignmentType.RIGHT;

// ------------------------------------------------------------------ cover page
const cp = (text, { size = 24, bold = false, before = 0, after = 0 } = {}) =>
  new Paragraph({ alignment: C, spacing: { before, after, line: 276 }, children: [new TextRun({ text, font: FONT, size, bold })] });

const cover = [
  cp(TITLE, { size: 34, bold: true, before: 300, after: 300 }),
  cp("Submitted for", { size: 28, bold: true, after: 200 }),
  cp("STATISTICAL MACHINE LEARNING", { size: 30, bold: true, after: 1100 }),
  cp("Submitted by:", { size: 24, after: 160 }),
  new Paragraph({ alignment: C, spacing: { after: 700 }, children: [
    new TextRun({ text: `(${STUDENT.enroll})`, font: FONT, size: 26, bold: true }),
    new TextRun({ text: "    ", font: FONT, size: 26 }),
    new TextRun({ text: STUDENT.name, font: FONT, size: 26, bold: true }) ] }),
  cp("Submitted to-", { size: 24, after: 160 }),
  cp(FACULTY, { size: 26, bold: true, after: 500 }),
  new Paragraph({ alignment: C, spacing: { after: 700 }, children: [
    new TextRun({ text: "GitHub Repository (public link): ", font: FONT, size: 24, bold: true }),
    new TextRun({ text: "[paste your public GitHub link here]", font: FONT, size: 24, highlight: "yellow" }) ] }),
  cp("July-Dec 2026", { size: 26, bold: true, after: 300 }),
  cp("SCHOOL OF COMPUTER SCIENCE ENGINEERING & TECHNOLOGY", { size: 32, bold: true, after: 300 }),
  new Paragraph({ alignment: C, spacing: { before: 60 }, children: [
    new ImageRun({ type: "png", data: IMG("logo.png"), transformation: { width: 340, height: 60 }, altText: { title: "Bennett University and NAAC A+ logo", description: "Bennett University, The Times Group, NAAC Grade A+ accredited university", name: "logo" } }) ] }),
];

// ------------------------------------------------------------------ front matter
const centerHead = (t) => new Paragraph({ alignment: C, spacing: { after: 300, before: 0 }, children: [new TextRun({ text: t, font: FONT, size: 32, bold: true })] });

const indexRows = [
  ["1", "Abstract", pg("1. ABSTRACT")],
  ["2", "Background", pg("2. BACKGROUND")],
  ["3", "Software / Hardware Used", pg("3. SOFTWARE / HARDWARE USED")],
  ["4", "Methodology", pg("4. METHODOLOGY")],
  ["5", "Experimental Results", pg("5. EXPERIMENTAL RESULTS")],
  ["6", "Conclusion", pg("6. CONCLUSION")],
  ["7", "References", pg("7. REFERENCES")],
];
const FIGS = [
  ["fig1", "System architecture of NewDay"],
  ["fig2", "Flowchart of processing one transaction"],
  ["fig3", "Expense category prediction pipeline"],
  ["fig4", "Accuracy of the three classifiers on seen and unseen words"],
  ["fig5", "Dashboard of the demo account (high savings)"],
  ["fig6", "Low savings after a large expense, and the large-expense popup"],
];
const TABS = [
  ["tab1", "Software used in the project"],
  ["tab2", "Savings status rule"],
  ["tab3", "Points needed to start each level"],
  ["tab4", "Comparison of the three classifiers"],
  ["tab5", "Effect of the confidence threshold on unseen words"],
  ["tab6", "Forecast error in a simulation (mean absolute error)"],
  ["tab7", "Large-expense detection in a simulation"],
  ["tab8", "Automated tests by area"],
];

const front = [
  centerHead("INDEX"),
  table([1100, 5400, 1835], ["Sr No", "Content", "Page No"], indexRows.map((r) => r), { aligns: [C, AlignmentType.LEFT, C] }),
  new Paragraph({ pageBreakBefore: true, alignment: C, spacing: { after: 300 }, children: [new TextRun({ text: "LIST OF FIGURES", font: FONT, size: 32, bold: true })] }),
  table([1300, 5500, 1535], ["Figure No.", "Title", "Page No."], FIGS.map(([k, t], i) => [String(i + 1), t, pg(k)]), { aligns: [C, AlignmentType.LEFT, C] }),
  new Paragraph({ pageBreakBefore: true, alignment: C, spacing: { after: 300 }, children: [new TextRun({ text: "LIST OF TABLES", font: FONT, size: 32, bold: true })] }),
  table([1300, 5500, 1535], ["Table No.", "Title", "Page No."], TABS.map(([k, t], i) => [String(i + 1), t, pg(k)]), { aligns: [C, AlignmentType.LEFT, C] }),
  new Paragraph({ spacing: { before: 300 }, children: [new TextRun({ text: "Note: List of Figures and List of Tables are on separate pages.", font: FONT, size: 24, bold: true })] }),
];

// ------------------------------------------------------------------ chapter 1
const ABSTRACT = "Many students and young earners run out of money before the month ends, because small daily expenses go unnoticed and most expense trackers only record spending without guiding the user. This project presents NewDay, a web based personal finance manager that records deposits, expenses and investments and shows the total available amount, the savings percentage and the amount that can still be spent in the current month. When savings fall to 40% of deposits or lower, the application shows a reminder in Hinglish asking the user to stop spending, and when savings reach 50% or more it tells the user that a little more spending is acceptable. A points system based on savings minus expenses moves the user through levels to make saving more engaging. Three machine learning components support the application: a text classifier that assigns each expense to one of ten categories, a ridge regression forecast of next month's spending, and an outlier detector for unusually large expenses. Three classifiers were compared. The calibrated linear support vector machine scored 99.3% on words seen in training but only 32.5% on unseen words, which shows the limit of synthetic training data. All 24 automated tests passed.";
console.log("Abstract words:", ABSTRACT.split(/\s+/).length);

const ch1 = [h1("1. ABSTRACT", { pageBreakBefore: true }), body(ABSTRACT)];

// ------------------------------------------------------------------ chapter 2
const ch2 = [
  h1("2. BACKGROUND", { pageBreakBefore: true }),
  h2("2.1 Introduction"),
  body("Managing money is a skill that most people learn by making mistakes. A student who receives pocket money or a stipend at the start of the month often spends freely in the first weeks and then struggles in the last days. Many mobile applications let users record their transactions, but a list of past expenses does not tell the user whether the present position is safe, and it gives little reason to keep using the application after the first few weeks. NewDay was designed to close this gap. It combines a simple record of deposits, expenses and investments with rule based guidance, machine learning support and a reward system, and it speaks to the user in Hinglish, the mixture of Hindi and English that many Indian users use in daily conversation."),
  h2("2.2 Problem statement"),
  body("The problem addressed in this project is how to help a person with regular income decide, at any moment, how much money is available, how much can safely be spent in the current month, and whether the present spending habit is healthy. The system must warn the user when savings become low, encourage the user when savings are high, and keep the user motivated over a long period. It must also reduce the effort of data entry by suggesting the category of each expense automatically."),
  h2("2.3 Relevance"),
  body("Spending decisions are made many times a day, so guidance is most useful when it is shown at the moment of spending. A reminder in the language that the user normally speaks is more likely to be read than a formal message. The project is also relevant to this course because it applies text classification, regression and outlier detection to a practical problem, and it forces an honest evaluation of how well each model works on data it has not seen before."),
  h2("2.4 Objectives"),
  ...bullets([
    "To record deposits, expenses and investments for every user and to show the total available amount.",
    "To calculate the savings percentage and the amount that can be spent this month and each day.",
    "To show Hinglish popups when savings are 40% or lower (low) and when they are 50% or higher (high).",
    "To award points equal to savings minus expenses and to move the user through levels.",
    "To classify expenses automatically, forecast next month's spending and detect unusually large expenses.",
  ]),
  h2("2.5 Literature review"),
  body("Deterding et al. [1] describe gamification as the use of game design elements in contexts that are not games. Levels, points and rewards are the most common of these elements. NewDay follows this idea by turning the difference between savings and expenses into points, so that good financial behaviour is rewarded in a visible way."),
  body("Text must be converted into numbers before a classifier can use it. Salton and Buckley [2] introduced term weighting by TF-IDF, which gives a high weight to a term that is frequent in one document but rare in the whole collection. Cavnar and Trenkle [3] showed that character n-grams are a robust way to represent text, because a small spelling mistake changes only a few of the n-grams. Expense notes such as \"zomato dinr\" or \"bijli bill\" are short, informal and written in mixed languages, so character n-grams suit them better than whole words. Writing that mixes English and Hindi in Roman script is common on social media, and Bali et al. [4] studied how speakers switch between the two languages inside one message."),
  body("Cortes and Vapnik [5] introduced the support vector machine, which finds the boundary that separates two classes with the largest margin. A plain SVM gives scores rather than probabilities, so Platt [6] proposed fitting a sigmoid function to the scores to obtain calibrated probabilities. This probability is what allows NewDay to say that it is not sure about a category. McCallum and Nigam [7] compared event models for naive Bayes text classification; naive Bayes and logistic regression are used here as simple baselines."),
  body("Hoerl and Kennard [8] proposed ridge regression, which adds a penalty on the size of the coefficients and gives stable estimates when data are few, as with six months of spending. For outliers, Liu et al. [9] proposed the isolation forest, which isolates unusual points with fewer random splits than normal points. When only a few expenses exist, a robust rule based on the median and the median absolute deviation is safer, and Iglewicz and Hoaglin [10] suggest treating a modified z-score above 3.5 as a possible outlier."),
  body("These works describe the methods separately. This project brings them together in one small application and measures their limits on a realistic task."),
];

// ------------------------------------------------------------------ chapter 3
const ch3 = [
  h1("3. SOFTWARE / HARDWARE USED"),
  body("Table 1 lists the software used. All of it is free and open source, apart from the browser used for testing, which is free to download."),
  caption("Table 1", "Software used in the project", "above"),
  table([1900, 3335, 3100], ["Component", "Software and version", "Purpose"], [
    ["Language", "Python 3.13", "Backend, machine learning, tests"],
    ["Web framework", "Flask 3.1, Werkzeug 3.1", "API, sessions, password hashing [12]"],
    ["Machine learning", "scikit-learn 1.9, NumPy 2.5, joblib 1.6", "Models, numerical work, saving the model [11]"],
    ["Database", "SQLite 3.53", "Users and transactions"],
    ["Frontend", "HTML, CSS, JavaScript", "Dashboard and popups, no framework"],
    ["Testing", "unittest, Playwright 1.63, Google Chrome", "Automated tests, browser walkthrough"],
    ["Figures", "Matplotlib 3.11", "Result charts"],
  ]),
  spacer(),
  body("The complete project has about 2,000 lines of code in Python, JavaScript, HTML and CSS. The source code, the dataset, the README file and the experiment results are in the public GitHub repository whose link is given on the cover page."),
  body("The project needs no special hardware. It was developed and tested on a Linux machine with two processor cores and 8 GB of memory and no graphics card. On this machine, training the final classifier on 3,000 expense notes took about 0.3 seconds, comparing all three models took about 1 second, and one category prediction took about 2 milliseconds. Any computer that can run Python 3 and a modern web browser should be enough for one user; about 4 GB of memory and 500 MB of free disk space are suggested, which is an estimate and not a measured limit."),
];

// ------------------------------------------------------------------ chapter 4
const ch4 = [
  h1("4. METHODOLOGY"),
  h2("4.1 System overview"),
  body("NewDay has three layers, shown in Figure 1. The browser shows the dashboard and the popups. A Flask application receives each request, checks it, and calls the finance rules, the machine learning models and the message module. SQLite stores the users and their transactions. The dashboard is calculated again from the stored transactions every time, so running totals can never fall out of step with the data."),
  figure("fig_architecture.png", 555, 238, "Architecture diagram"),
  caption("Figure 1", "System architecture of NewDay", "below"),
  h2("4.2 Flowchart"),
  body("Figure 2 shows what happens when a user adds an entry. The input is checked first. For an expense, the classifier suggests the category. The entry is saved, all figures are recalculated, and the savings ratio decides which popup is shown. A large expense or a new level adds further popups, and the dashboard is then redrawn."),
  figure("fig_flowchart.png", 440, 503, "Flowchart of processing one transaction"),
  caption("Figure 2", "Flowchart of processing one transaction", "below"),
  h2("4.3 Data stored"),
  body("The database has two tables. The users table keeps the user name, a salted password hash and the highest level reached. The transactions table keeps the type (deposit, expense or investment), the amount, which must be greater than zero, the category, a short description and the date. Investments are stored as their own type and are never counted as expenses."),
  h2("4.4 Finance rules"),
  body("Let D be the total deposited, E the total expenses and I the money invested. The total available amount is D − E, which is made of cash (D − E − I) and invested money. The savings ratio is r = (D − E) / D. It uses the deposits of the current month when money was deposited this month, and all deposits otherwise. The status follows Table 2. The brief did not say what to do between 40% and 50%, so that range is treated as balanced and a neutral message is shown."),
  caption("Table 2", "Savings status rule", "above"),
  table([2800, 1900, 3635], ["Savings ratio r", "Status", "Popup shown"], [
    ["50% or more", "High", "You can spend a little more"],
    ["Above 40% and below 50%", "Balanced", "Neutral message"],
    ["40% or less", "Low", "Stop spending"],
  ]),
  spacer(),
  body("The amount that can be spent this month is the smaller of the available cash and (50% × income of the month − expenses of the month). Spending up to this limit keeps the ratio at 50% or more. The daily limit is this amount divided by the days left in the month. For example, with ₹10,000 deposited and ₹2,000 spent, the limit is ₹3,000, and with 16 days left it is ₹187.50 a day."),
  body("Points are P = (D − E) − E, that is, savings minus expenses, and are never below zero. The first level needs 5,000 points to cross. Table 3 gives the points at which each level starts. Each level has a name, a title and a surprise message kept in a configuration file, so they can be changed without changing the program. A level-up popup is shown only when the user reaches a new highest level."),
  caption("Table 3", "Points needed to start each level", "above"),
  table([895, 930, 930, 930, 930, 930, 930, 930, 930],
    ["Level", "1", "2", "3", "4", "5", "6", "7", "8"],
    [["Points", "0", "5,000", "15,000", "30,000", "50,000", "80,000", "1,20,000", "2,00,000"]],
    { size: 18, aligns: [AlignmentType.LEFT, C, C, C, C, C, C, C, C] }),
  spacer(),
  h2("4.5 Machine learning methods"),
  body("Category classifier. No public dataset of Hinglish spending notes was available, so 3,000 labelled notes were generated, 300 for each of ten categories. A note is built from a keyword such as \"chai\", \"bijli bill\" or \"uber\", taken from lists of about 25 to 40 English and Hinglish keywords per category, with a random prefix or suffix such as \"paid\" or \"upi\", random capital letters, and in 15% of cases a dropped or swapped letter. The dataset is in the dataset folder of the repository. The text is turned into TF-IDF features over character n-grams of length 2 to 4 and passed to a classifier, as shown in Figure 3. Three classifiers were compared: logistic regression, multinomial naive Bayes and a linear SVM with sigmoid calibration. If the highest class probability is below 0.35, the category is set to Other and the user is asked to choose."),
  figure("fig_pipeline.png", 555, 218, "Classifier pipeline"),
  caption("Figure 3", "Expense category prediction pipeline", "below"),
  body("Each model was tested in two ways. In the seen-words test, the notes were split at random into 80% for training and 20% for testing, so the same keywords appear on both sides. In the unseen-words test, 20% of the keywords of each category were removed from training completely and used only for testing, which shows whether the model can handle new words. The final model was chosen by the macro F1 score on unseen words."),
  body("Spending forecast. The totals of the last six finished months are used. If there are three or more months, a ridge regression with penalty 0.1 is fitted on the month number and extended by one month, and the result is limited to between zero and 1.5 times the highest month. With one or two months the average is used."),
  body("Large expense detection. A new expense is checked against the earlier expenses of the same user. Nothing is flagged until five earlier expenses exist, and only amounts above 1.5 times the median can be flagged. With fewer than 30 earlier expenses the modified z-score z = 0.6745 (x − median) / MAD is used, and an amount is flagged when z is above 3.5 [10]. With 30 or more, an isolation forest with 100 trees is fitted on the logarithm of the amounts [9]."),
  h2("4.6 Hinglish alerts and testing"),
  body("Each popup type has several messages written in Hinglish, and one is chosen at random so that the user does not see the same line every time. For example, the low popup says \"Yaar, paisa kaafi kam bach gaya hai\" and the high popup says \"Wah! Tu toh champion nikla\". The rules, models and the web interface were tested with 24 automated tests, a browser walkthrough with a demo account, and simulations of the forecast and the outlier detector."),
];

// ------------------------------------------------------------------ chapter 5
const ch5 = [
  h1("5. EXPERIMENTAL RESULTS"),
  h2("5.1 Category classifier"),
  body("Table 4 and Figure 4 compare the three classifiers. All three score about 99% when the test words were seen in training. On unseen words the scores fall to between 29.6% and 32.5%. The calibrated linear SVM was best on unseen words, with an accuracy of 32.5% and a macro F1 of 0.305, so it was chosen."),
  caption("Table 4", "Comparison of the three classifiers", "above"),
  table([3000, 1800, 1800, 1735], ["Model", "Seen-word accuracy", "Unseen-word accuracy", "Unseen macro F1"], [
    ["Logistic regression", "99.3%", "29.6%", "0.286"],
    ["Multinomial naive Bayes", "99.2%", "31.4%", "0.295"],
    ["Linear SVM (calibrated)", "99.3%", "32.5%", "0.305"],
  ], { aligns: [AlignmentType.LEFT, C, C, C], boldCells: [[2, 0], [2, 2], [2, 3]] }),
  spacer(),
  figure("fig_models.png", 450, 225, "Bar chart of seen and unseen word accuracy"),
  caption("Figure 4", "Accuracy of the three classifiers on seen and unseen words", "below"),
  body("The large gap between the two tests shows that character n-grams only generalise to spellings close to words already seen. On unseen words, the F1 score of the chosen model was highest for Education (0.597) and Bills and Recharge (0.593), whose words share endings such as \"bill\" and \"fee\", and lowest for Health (0.055) and Groceries (0.138). To test robustness to spelling mistakes, words seen in training were changed by a dropped or swapped letter (words of five or more letters only). The accuracy was 100% with no mistakes, 99.2% when 15% of words were changed, 97.5% when half were changed and 95.8% when every long word was changed. The model therefore handles typing mistakes well, but not new words."),
  body("The confidence threshold was studied on the 800 unseen-word notes. Table 5 shows that the share of predictions kept falls and the accuracy of the kept predictions rises as the threshold increases. If rejected notes are set to Other, the overall accuracy is highest at a threshold of 0.35 (37.1%, against 32.5% with no threshold), which is the value used in the application. Higher thresholds reject too many notes."),
  caption("Table 5", "Effect of the confidence threshold on unseen words", "above"),
  table([1700, 2200, 2400, 2035], ["Threshold", "Predictions kept", "Accuracy of kept", "Overall with Other"], [
    ["0 (none)", "100.0%", "32.5%", "32.5%"],
    ["0.25", "95.5%", "34.0%", "35.5%"],
    ["0.35", "87.8%", "37.0%", "37.1%"],
    ["0.50", "67.8%", "43.4%", "34.0%"],
    ["0.60", "52.4%", "50.6%", "33.0%"],
  ], { aligns: [C, C, C, C], boldCells: [[2, 0], [2, 1], [2, 2], [2, 3]] }),
  spacer(),
  h2("5.2 Spending forecast"),
  body("Real spending histories were not available, so the forecast was tested on simulated users. In each simulation 400 users had six months of spending around a base value between ₹4,000 and ₹15,000, with random variation of 10% of the base, and the seventh month had to be predicted. In one setting the spending was flat, and in the other it rose by about 4% of the base each month. Table 6 gives the mean absolute error in rupees. With a rising trend the ridge regression was best (₹1,075 against ₹1,517 for the average of six months). With flat spending the plain average was better (₹845 against ₹1,008), because the fitted line follows noise. Six points give a weak estimate of the trend, so a future version should choose between the two methods automatically."),
  caption("Table 6", "Forecast error in a simulation (mean absolute error)", "above"),
  table([3000, 2700, 2635], ["Method", "Flat spending (₹)", "Rising spending (₹)"], [
    ["Ridge regression (used)", "1,008", "1,075"],
    ["Average of six months", "845", "1,517"],
    ["Last month", "1,090", "1,154"],
  ], { aligns: [AlignmentType.LEFT, C, C], boldCells: [[1, 1], [0, 2]] }),
  spacer(),
  h2("5.3 Large expense detection"),
  body("The detector was tested on simulated users whose normal expenses followed a log-normal distribution with a median between ₹120 and ₹400. Each user then made 20 normal expenses and 5 large ones, between 5 and 15 times the median. Table 7 shows the results. With 10 earlier expenses the median rule found every large expense, but 6.7% of normal expenses were also flagged. With 40 earlier expenses the isolation forest found 95.0% of the large expenses, flagged 3.3% of normal ones, and 87.7% of its alerts were correct. The large expenses in the simulation are fairly obvious, so results on real data will be lower."),
  caption("Table 7", "Large-expense detection in a simulation", "above"),
  table([1500, 2100, 1300, 1350, 1250, 835], ["Earlier expenses", "Method", "Recall", "Precision", "False alarms", "Users"], [
    ["10", "Median and MAD rule", "100.0%", "78.9%", "6.7%", "200"],
    ["40", "Isolation forest", "95.0%", "87.7%", "3.3%", "60"],
  ], { aligns: [C, AlignmentType.LEFT, C, C, C, C] }),
  spacer(),
  h2("5.4 System testing and demonstration"),
  body("All 24 automated tests passed (Table 8). They check the 40% and 50% boundaries exactly, the points and level rules, the monthly limit, the Hinglish messages, the three models, and the web interface, including login, input checks and the rule that one user cannot see another user's data."),
  caption("Table 8", "Automated tests by area", "above"),
  table([2400, 900, 5035], ["Area", "Tests", "What is checked"], [
    ["Status rule", "3", "Exactly 50% is high, exactly 40% is low, the range between is balanced"],
    ["Points and levels", "4", "Points never negative; 4,999 points is level 1, 5,000 is level 2"],
    ["Monthly budget", "3", "Allowance, remaining amount, daily limit, overspending"],
    ["Hinglish popups", "2", "Percentage appears in the message; rupee format"],
    ["Machine learning", "4", "Categories, low-confidence fallback, forecast, outliers"],
    ["Web interface (API)", "8", "Login, invalid input, popups, level-up, user isolation"],
    ["Total", "24", "All passed"],
  ], { aligns: [AlignmentType.LEFT, C, AlignmentType.LEFT], boldCells: [[6, 0], [6, 1], [6, 2]] }),
  spacer(),
  body("A browser walkthrough was done with a demo account that had ₹60,000 deposited over four months and ₹25,615 spent. Figure 5 shows the dashboard: 75% saved this month (high), ₹3,003 that can still be spent, and Level 2 with 8,770 points. The user then added a dinner of ₹4,500. The large-expense popup appeared first, followed by the low-savings popup, because savings fell to 38%. Figure 6 shows the result: the gauge moved to the low zone, the amount that can be spent became ₹0, and the level fell to Level 1 because the points fell to zero. No script errors were recorded, and the page had no sideways scrolling at phone width."),
  figure("fig_dashboard.png", 500, 344, "Dashboard of the demo account"),
  caption("Figure 5", "Dashboard of the demo account (high savings)", "below"),
  figure("fig_low_popup.png", 555, 193, "Dashboard after the expense and the popup"),
  caption("Figure 6", "Low savings after a large expense (left) and the large-expense popup (right)", "below"),
  h2("5.5 Limits of the results"),
  body("The classifier was trained and tested on generated notes, and the forecast and outlier tests used simulated users, so the figures show how the methods behave under stated assumptions and not how they will perform for real users. The low accuracy on unseen words is the main weakness, and it is the reason the application asks the user to confirm uncertain categories."),
];

// ------------------------------------------------------------------ chapter 6
const ch6 = [
  h1("6. CONCLUSION"),
  body("NewDay meets the objectives of the project. It records deposits, expenses and investments, shows the total available amount, calculates how much can be spent this month and each day, and warns the user in Hinglish when savings are 40% or lower, and encourages the user when savings are 50% or higher. Points equal to savings minus expenses move the user through levels, with a surprise message at each new level. The rules were verified exactly by 24 automated tests and by a browser walkthrough."),
  body("The machine learning components worked as designed but showed clear limits. The category classifier was accurate on words it had seen (about 99%) and on spelling mistakes (95.8% even when every long word was changed), but it reached only 32.5% on words it had never seen, because it was trained on generated data. A confidence threshold of 0.35 improved the overall accuracy on unseen words from 32.5% to 37.1% and lets the user correct uncertain cases. The ridge forecast was better than the average when spending was rising and worse when it was flat. The outlier detector found most large expenses in simulation with a few false alarms."),
  body("In future work, the classifier should learn from the corrections that users make, and word embeddings could help it with unseen words. The forecast could choose automatically between the average and the trend. Further additions are budgets for each category, import of bank or UPI statements, phone notifications, and stronger account security such as email verification and protection against cross-site request forgery."),
];

// ------------------------------------------------------------------ chapter 7
const REFS = [
  "S. Deterding, D. Dixon, R. Khaled and L. Nacke, \"From game design elements to gamefulness: defining gamification,\" in Proc. 15th Int. Academic MindTrek Conf., Tampere, Finland, 2011, pp. 9–15.",
  "G. Salton and C. Buckley, \"Term-weighting approaches in automatic text retrieval,\" Information Processing & Management, vol. 24, no. 5, pp. 513–523, 1988.",
  "W. B. Cavnar and J. M. Trenkle, \"N-gram-based text categorization,\" in Proc. 3rd Annual Symp. on Document Analysis and Information Retrieval, Las Vegas, NV, 1994, pp. 161–175.",
  "K. Bali, J. Sharma, M. Choudhury and Y. Vyas, \"I am borrowing ya mixing? An analysis of English-Hindi code mixing in Facebook,\" in Proc. First Workshop on Computational Approaches to Code Switching, EMNLP, Doha, Qatar, 2014.",
  "C. Cortes and V. Vapnik, \"Support-vector networks,\" Machine Learning, vol. 20, no. 3, pp. 273–297, 1995.",
  "J. C. Platt, \"Probabilistic outputs for support vector machines and comparisons to regularized likelihood methods,\" in Advances in Large Margin Classifiers, MIT Press, 1999, pp. 61–74.",
  "A. McCallum and K. Nigam, \"A comparison of event models for naive Bayes text classification,\" in AAAI-98 Workshop on Learning for Text Categorization, 1998, pp. 41–48.",
  "A. E. Hoerl and R. W. Kennard, \"Ridge regression: biased estimation for nonorthogonal problems,\" Technometrics, vol. 12, no. 1, pp. 55–67, 1970.",
  "F. T. Liu, K. M. Ting and Z.-H. Zhou, \"Isolation forest,\" in Proc. 8th IEEE Int. Conf. on Data Mining, Pisa, Italy, 2008, pp. 413–422.",
  "B. Iglewicz and D. C. Hoaglin, How to Detect and Handle Outliers. Milwaukee, WI, USA: ASQC Quality Press, 1993.",
  "F. Pedregosa et al., \"Scikit-learn: machine learning in Python,\" Journal of Machine Learning Research, vol. 12, pp. 2825–2830, 2011.",
  "Pallets Projects, \"Flask documentation,\" https://flask.palletsprojects.com (accessed Nov. 2026).",
];
const ch7 = [
  h1("7. REFERENCES"),
  ...REFS.map((t, i) => new Paragraph({
    alignment: AlignmentType.JUSTIFIED, spacing: { line: BODY_LINE, after: 160 },
    indent: { left: 567, hanging: 567 },
    children: [run(`[${i + 1}]\t${t}`)],
    tabStops: [{ type: "left", position: 567 }],
  })),
];

// ------------------------------------------------------------------ document
const pageMargin = { top: 1417, right: 1417, bottom: 1417, left: 1417, gutter: 737, header: 709, footer: 709 };
const pageSize = { width: 11906, height: 16838 };
const doc = new Document({
  creator: STUDENT.name,
  title: TITLE,
  description: "Project report for Statistical Machine Learning, Bennett University, July-Dec 2026",
  styles: {
    default: { document: { run: { font: FONT, size: 24 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 32, bold: true, color: "000000" },
        paragraph: { spacing: { before: 120, after: 300, line: 360 }, keepNext: true, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 24, bold: true, color: "000000" },
        paragraph: { spacing: { before: 60, after: 160, line: 360 }, keepNext: true, outlineLevel: 1 } },
    ],
  },
  numbering: { config: [{ reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] }] },
  sections: [
    { properties: { page: { size: pageSize, margin: pageMargin } }, children: cover },
    { properties: { page: { size: pageSize, margin: pageMargin } },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: C, children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 24 })] })] }) },
      children: [...front, ...ch1, ...ch2, ...ch3, ...ch4, ...ch5, ...ch6, ...ch7] },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  const out = path.join(HERE, "..", "NewDay_Project_Report_Bennett.docx");
  fs.writeFileSync(out, buf);
  console.log("written", out);
});
