"""Export the datasets used by NewDay to ../dataset/ as CSV files.

    python export_dataset.py

Creates:
  training_data_synthetic.csv  - labelled expense notes used to train the category classifier
  category_keywords.csv        - the keyword lists the notes are generated from
  demo_transactions.csv        - four months of demo deposits, expenses and investments
All data is synthetic (generated), not collected from real people.
"""
import csv
import os
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE.parent / "dataset"
OUT.mkdir(exist_ok=True)

# Use a throw-away database so exporting never touches a real one.
os.environ["NEWDAY_DB"] = str(Path(tempfile.mkdtemp()) / "export.db")
sys.path.insert(0, str(HERE))

import db  # noqa: E402
import seed_demo  # noqa: E402
import training_data  # noqa: E402


def write(name, header, rows):
    with open(OUT / name, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)
    print(f"{name}: {len(rows)} rows")


texts, labels = training_data.build_dataset(per_class=300, seed=42)
write("training_data_synthetic.csv", ["text", "category"], list(zip(texts, labels)))

write("category_keywords.csv", ["category", "keyword"],
      [(cat, kw) for cat, kws in training_data.KEYWORDS.items() for kw in kws])

uid = seed_demo.seed(today=__import__("datetime").date(2026, 11, 15))
txs = db.list_transactions(uid)
write("demo_transactions.csv", ["date", "type", "amount", "category", "description"],
      [(t["date"], t["type"], t["amount"], t["category"], t["description"]) for t in txs])
