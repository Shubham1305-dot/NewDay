"""Hinglish popup messages. Add or edit lines freely: {placeholders} are filled in."""
import random

rng = random.Random()  # tests can replace this with a seeded Random


def inr(n):
    """Format a number the Indian way: 1234567 -> ₹12,34,567."""
    n = int(round(n))
    neg = n < 0
    s = str(abs(n))
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        s = ",".join(parts + [tail])
    return ("-" if neg else "") + "₹" + s


LOW = [
    "Yaar, paisa kaafi kam bach gaya hai, sirf {saved_pct}% bachat bachi hai. Ab kharche rok de, warna mahine ke end mein haath tang ho jayega! 🚨",
    "Arre bhai, thoda ruk ja! Teri bachat sirf {saved_pct}% reh gayi hai. Sirf zaroori cheezein hi kharid, baaki baad mein. 🛑",
    "Wallet ro raha hai 😅 Bachat {saved_pct}% pe aa gayi. Aaj ka kharcha skip kar de, future-you thank you bolega.",
    "Dhyan de! {saved_pct}% bachat matlab danger zone. Ab 'chai-samosa' wale chhote kharche bhi count karna shuru kar. ⚠️",
]

HIGH = [
    "Wah! {saved_pct}% bachat, tu toh champion nikla 🎉 Thoda sa kharcha kar sakta hai, bas control mein rehna!",
    "Mast chal raha hai! Bachat {saved_pct}% hai. Chhota sa treat de de apne aap ko 😎 par limit mein.",
    "Paisa safe hai ({saved_pct}% bachat). Thoda enjoy kar le, tu deserve karta hai. Bas budget ke andar! ✨",
    "Zabardast! {saved_pct}% bachat ke baad ek chhota kharcha banta hai 🥳 Is mahine abhi {remaining} tak kharch kar sakta hai.",
]

BALANCED = [
    "Sab balanced hai 👍 Bachat {saved_pct}% hai. 50% tak pahunch gaya toh full mazaa!",
]

OVERSPEND = [
    "Is mahine ka budget cross ho gaya, bhai! 🚫 Ab baaki din sirf bahut zaroori kharcha karna.",
    "Budget ki line paar ho gayi 😬 Mahine ke baaki din control mein rakh, warna bachat gir jayegi.",
]

ANOMALY = [
    "Hmm, {amount} ka kharcha tere normal se kaafi bada lag raha hai 🤔 Sach mein zaroori tha?",
    "Ye {amount} wala kharcha alag hi level ka hai! 👀 Ek baar dobara soch le, kya ye plan mein tha?",
]

LEVELUP = [
    "🎉 Level Up! Ab tu {name} ({title}) ban gaya! {reward}",
]

SURPRISES = [
    "🎁 Challenge: aaj ka din 'no-spend day' bana. Sirf zaroori cheezein, baaki kal.",
    "🎁 Tip: kharcha karne se pehle 24 ghante ruk. Aadhe kharche khud hi cancel ho jaate hain!",
    "🎁 Fun fact: har mahine sirf ₹500 bachaye toh saal ke ₹6,000 ho jaate hain. Chhoti bachat, badi shuruaat!",
    "🎁 Tip: salary/pocket money aate hi pehle bachat alag kar, phir kharcha kar. 'Pay yourself first'!",
    "🎁 Challenge: is hafte ke saare chhote kharche (chai, snacks) note kar. Total dekh ke hairaan ho jayega 😄",
    "🎁 Tip: 50-30-20 rule try kar: 50% zaroorat, 30% shauk, 20% bachat ya investment.",
    "🎁 Challenge: ek purani subscription jo use nahi hoti, aaj hi cancel kar de.",
    "🎁 Tip: emergency fund pehle, investment baad mein. Pehle suraksha, phir growth. 🛡️",
]


def _pick(options, **ctx):
    return rng.choice(options).format(**ctx)


def status_popup(status, saved_pct, remaining=0, daily=0):
    """Popup for the savings status, or None when there is nothing to say."""
    ctx = {"saved_pct": saved_pct, "remaining": inr(remaining), "daily": inr(daily)}
    if status == "low":
        return {"kind": "low", "icon": "🚨", "title": "Kharcha rok do!", "message": _pick(LOW, **ctx)}
    if status == "high":
        # Don't promise "you can spend ₹0": skip amount-based lines when nothing is left to spend.
        options = HIGH if remaining > 0 else [m for m in HIGH if "{remaining}" not in m]
        return {"kind": "high", "icon": "🎉", "title": "Mast chal raha hai!", "message": _pick(options, **ctx)}
    if status == "balanced":
        return {"kind": "balanced", "icon": "👍", "title": "Sab theek hai", "message": _pick(BALANCED, **ctx)}
    return None


def overspend_popup():
    return {"kind": "overspend", "icon": "🚫", "title": "Budget cross!", "message": _pick(OVERSPEND)}


def anomaly_popup(amount):
    return {"kind": "anomaly", "icon": "🤔", "title": "Ye kharcha bada hai", "message": _pick(ANOMALY, amount=inr(amount))}


def levelup_popup(name, title, reward):
    return {"kind": "levelup", "icon": "🏆", "title": "Level Up!", "message": _pick(LEVELUP, name=name, title=title, reward=reward)}


def surprise():
    return rng.choice(SURPRISES)
