"""NewDay Flask API + static frontend.

Run:  python app.py      then open http://127.0.0.1:5000
"""
import math
import os
import re
import secrets
import time
from collections import defaultdict
from datetime import date, datetime, timedelta
from functools import wraps

from flask import Flask, jsonify, request, send_from_directory, session
from werkzeug.security import check_password_hash, generate_password_hash

import config
import db
import finance
import messages
import ml

USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,30}$")
TX_TYPES = ("deposit", "expense", "investment")


def _secret_key():
    env = os.environ.get("NEWDAY_SECRET")
    if env:
        return env
    path = config.BASE_DIR / "data" / ".secret"
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(secrets.token_hex(32))
    return path.read_text().strip()


def _error(message, status=400):
    return jsonify({"error": message}), status


def _parse_amount(value):
    if isinstance(value, bool):
        raise ValueError
    amount = float(value)
    if not math.isfinite(amount) or amount <= 0 or amount > 1e9:
        raise ValueError
    return round(amount, 2)


def create_app():
    app = Flask(__name__, static_folder=str(config.FRONTEND_DIR), static_url_path="")
    app.secret_key = _secret_key()
    app.config.update(SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_HTTPONLY=True,
                      MAX_CONTENT_LENGTH=64 * 1024)
    db.init_db()
    fails = defaultdict(list)  # ip -> timestamps of failed logins

    def login_required(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user = db.get_user(session["uid"]) if "uid" in session else None
            if not user:
                session.clear()
                return _error("Please log in first.", 401)
            return fn(user, *args, **kwargs)
        return wrapper

    # ---- pages ----------------------------------------------------------
    @app.get("/")
    def index():
        return send_from_directory(config.FRONTEND_DIR, "index.html")

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok"})

    # ---- auth -----------------------------------------------------------
    @app.post("/api/register")
    def register():
        body = request.get_json(silent=True) or {}
        username = str(body.get("username", "")).strip()
        name = str(body.get("name", "")).strip()[:40] or username
        password = str(body.get("password", ""))
        if not USERNAME_RE.match(username):
            return _error("Username must be 3-30 letters, numbers or underscores.")
        if len(password) < 6:
            return _error("Password must be at least 6 characters.")
        uid = db.create_user(username, name, generate_password_hash(password))
        if uid is None:
            return _error("That username is taken. Try another one.", 409)
        session.clear()
        session["uid"] = uid
        return jsonify({"user": {"name": name, "username": username.lower()}}), 201

    @app.post("/api/login")
    def login():
        now = time.time()
        ip = request.remote_addr or "?"
        fails[ip] = [t for t in fails[ip] if now - t < config.LOGIN_WINDOW_SECONDS]
        if len(fails[ip]) >= config.MAX_LOGIN_FAILS:
            return _error("Too many attempts. Wait a few minutes and try again.", 429)
        body = request.get_json(silent=True) or {}
        user = db.get_user_by_username(str(body.get("username", "")).strip())
        if not user or not check_password_hash(user["password_hash"], str(body.get("password", ""))):
            fails[ip].append(now)
            return _error("Wrong username or password.", 401)
        session.clear()
        session["uid"] = user["id"]
        return jsonify({"user": {"name": user["name"], "username": user["username"]}})

    @app.post("/api/logout")
    def logout():
        session.clear()
        return jsonify({"ok": True})

    @app.get("/api/me")
    def me():
        """Who is logged in? Always 200 so a first visit doesn't log a 401 in the console."""
        user = db.get_user(session["uid"]) if "uid" in session else None
        if not user:
            return jsonify({"user": None})
        return jsonify({"user": {"name": user["name"], "username": user["username"]}})

    # ---- dashboard ------------------------------------------------------
    def dashboard_payload(user, txs=None):
        txs = txs if txs is not None else db.list_transactions(user["id"])
        summary = finance.compute_summary(txs)
        summary["user"] = {"name": user["name"], "username": user["username"]}
        summary["category_list"] = config.CATEGORIES
        summary["recent"] = list(reversed(txs))[:30]
        return summary

    @app.get("/api/dashboard")
    @login_required
    def dashboard(user):
        return jsonify(dashboard_payload(user))

    @app.get("/api/levels")
    @login_required
    def levels(user):
        return jsonify({"levels": finance.load_levels()})

    # ---- transactions ---------------------------------------------------
    @app.post("/api/transactions")
    @login_required
    def add_transaction(user):
        body = request.get_json(silent=True) or {}
        type_ = body.get("type")
        if type_ not in TX_TYPES:
            return _error("Type must be deposit, expense or investment.")
        try:
            amount = _parse_amount(body.get("amount"))
        except (TypeError, ValueError):
            return _error("Enter an amount greater than 0.")
        try:
            day = datetime.strptime(str(body.get("date") or date.today().isoformat()), "%Y-%m-%d").date()
        except ValueError:
            return _error("Date must look like 2026-11-15.")
        # One day of slack: the browser's "today" can be a day ahead of the server's (time zones).
        if day > date.today() + timedelta(days=1):
            return _error("Date can't be in the future.")
        description = str(body.get("description", "")).strip()[:80]

        if type_ == "expense":
            category = body.get("category")
            if not category:
                if not description:
                    return _error("Add a description so we can find the category.")
                category = ml.predict_category(description)["category"]
            if category not in config.CATEGORIES:
                return _error("Unknown category.")
        else:
            category = "Deposit" if type_ == "deposit" else "Investment"
            description = description or category

        before_txs = db.list_transactions(user["id"])
        before = finance.compute_summary(before_txs)
        history = [t["amount"] for t in before_txs if t["type"] == "expense"]

        tx = db.add_transaction(user["id"], type_, amount, category, description, day.isoformat())
        after_txs = before_txs + [tx]
        payload = dashboard_payload(user, after_txs)

        popups = []
        lvl = payload["level"]
        if lvl["level"] > user["max_level"]:
            db.set_max_level(user["id"], lvl["level"])
            popups.append(messages.levelup_popup(lvl["name"], lvl["title"], lvl["reward"]))
        if type_ == "expense":
            if ml.is_anomalous(amount, history):
                popups.append(messages.anomaly_popup(amount))
            status_popup = payload["popup"] if payload["popup"] and payload["popup"]["kind"] in ("low", "high") else None
            # "Budget crossed" and "low" give the same warning, so only show one of them.
            if payload["month"]["overspent"] and not before["month"]["overspent"] and not (status_popup and status_popup["kind"] == "low"):
                popups.append(messages.overspend_popup())
            if status_popup:
                popups.append(status_popup)
        return jsonify({"transaction": tx, "dashboard": payload, "popups": popups}), 201

    @app.delete("/api/transactions/<int:tx_id>")
    @login_required
    def delete_transaction(user, tx_id):
        if not db.delete_transaction(user["id"], tx_id):
            return _error("Transaction not found.", 404)
        return jsonify({"dashboard": dashboard_payload(user)})

    @app.post("/api/categorize")
    @login_required
    def categorize(user):
        body = request.get_json(silent=True) or {}
        return jsonify(ml.predict_category(str(body.get("description", ""))[:80]))

    @app.get("/api/surprise")
    @login_required
    def surprise(user):
        return jsonify({"message": messages.surprise()})

    @app.errorhandler(404)
    def not_found(_):
        if request.path.startswith("/api/"):
            return _error("Not found.", 404)
        return send_from_directory(config.FRONTEND_DIR, "index.html")

    return app


if __name__ == "__main__":
    create_app().run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=False)
