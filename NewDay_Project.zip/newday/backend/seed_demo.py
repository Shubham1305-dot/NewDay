"""Create a demo account with ~4 months of realistic data.

    python seed_demo.py        ->  login: demo / demo123
"""
import random
from datetime import date, timedelta

from werkzeug.security import generate_password_hash

import config
import db
import ml

EXPENSES = [
    ("chai samosa", 40, 90), ("lunch canteen", 80, 160), ("zomato dinner", 180, 420), ("metro card recharge", 100, 300),
    ("uber ride", 120, 350), ("sabzi", 60, 200), ("milk", 30, 70), ("netflix", 199, 199), ("jio recharge", 299, 299),
    ("movie pvr", 250, 500), ("books", 200, 800), ("medicine", 80, 400), ("amazon shirt", 500, 1500),
    ("wifi bill", 500, 700), ("burger", 90, 200), ("auto", 30, 120), ("coffee", 80, 180),
]


def seed(username="demo", password="demo123", name="Demo Student", today=None):
    db.init_db()
    if db.get_user_by_username(username):
        return None
    uid = db.create_user(username, name, generate_password_hash(password))
    rng = random.Random(2026)
    today = today or date.today()
    start = today - timedelta(days=118)
    d = start
    while d <= today:
        if d.day == 1 or d == start:  # monthly pocket money / stipend
            db.add_transaction(uid, "deposit", 12000, "Deposit", "Monthly pocket money", d.isoformat())
        if d.day == 15:
            db.add_transaction(uid, "investment", rng.choice([500, 1000]), "Investment", "Mutual fund SIP", d.isoformat())
        for _ in range(rng.choice([0, 0, 1, 1, 2])):
            desc, lo, hi = rng.choice(EXPENSES)
            amount = round(rng.uniform(lo, hi))
            db.add_transaction(uid, "expense", amount, ml.predict_category(desc)["category"], desc, d.isoformat())
        d += timedelta(days=1)
    return uid


if __name__ == "__main__":
    uid = seed()
    print("Demo user created (demo / demo123)." if uid else "Demo user already exists.")
